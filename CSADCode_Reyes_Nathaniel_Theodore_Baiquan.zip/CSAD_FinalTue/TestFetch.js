var lastID = 0;
var selectedID = 0;
//set token
var Cassandra_Token = "AstraCS:seSLgQJNakqamZKmAFILlZEk:416a2c7155bb21ce24ffde30fb2ddf463e4e62482572fe7aa74ba69c58c2cd33";
//region url
var region = " https://9ac24955-5187-4735-ab61-bc2524da2b58-asia-south1.apps.astra.datastax.com";
//Testing Table url
var url = region + "/api/rest/v2/keyspaces/sellable/testing_table/";
//Account Url
var registerUrl = region + "/api/rest/v2/keyspaces/sellable/accountdatatable/";
//Testing Image Saving Url
var testpic = region + "/api/rest/v2/keyspaces/sellable/test_image/";
//Item Url
var itemUrl = region + "/api/rest/v2/keyspaces/sellable/items/";
//Message Url
var messageUrl = region + "/api/rest/v2/keyspaces/sellable/message_table/";
//Chat Url
var chatUrl = region + "/api/rest/v2/keyspaces/sellable/chat_table/";
//Liked Url
var likedUrl = region + "/api/rest/v2/keyspaces/sellable/like_table/";
//Review Url
var reviewUrl = region + "/api/rest/v2/keyspaces/sellable/newreview/";
//settings Url
var settingUrl = region + "/api/rest/v2/keyspaces/sellable/desc_table/";
//Profile Url
var profileUrl = region + "/api/rest/v2/keyspaces/sellable/profile_images/";
//http header
var myHeaders = new Headers();
myHeaders.append("Content-Type","application/json");
myHeaders.append("X-Cassandra-Token",Cassandra_Token);
myHeaders.append("Accept","application/json");


//Read all records from the database
async function getAllRecords(){
    const options = {
        method: "get",
        headers: myHeaders
    };
    try{
        let response = await fetch(url + "rows", options);
        let data = await response.json();
        alert(response.status);
        return response;
    } catch(error){
        console.log(error);
    }
}

//Read a record  uisng the primary key. id
async function getRecordById(id){
    const options = {
        method: "get",
        headers: myHeaders
    };
    try{
        let response = await fetch(url + id, options);
        return response;
    }catch(error){
        console.log(error);
    }
}

//Insert current record
async function saveRecord(){
    if(true){
        let name = document.getElementById("name").value;
        let no1 = document.getElementById("no1").value;
        let no2 = document.getElementById("no2").value;
        lastID += 1;
        let updatedata = '{"id":"'+lastID+'","name" : "'+name+'","no1":"'+no1+'","no2":"'+no2+'"}';
        alert(updatedata);
        const options = {
            method: "post",
            headers: myHeaders,
            body: updatedata
        };
        try{
            let response = await fetch(url,options);
            alert(response.status);
            if(response.status===201){
                alert('Insert Successfully');
            }else{
                alert('Insert fail');
            }
        }catch(error){
            console.log(error);
        }
    }
}

//ACCOUNT CREATION....

//Global Variables

//Validate New Account Details
function validateNewAcc(){
    registerErrorReset();
    var error = false;
    let username = document.getElementById("newUser").value;
    let email = document.getElementById("emailAddress").value;
    let password = document.getElementById("newPassword").value;
    let confirmPassword = document.getElementById("confirmPassword").value;
    
    //Email Detector
    var validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    
    if(username.trim() === ""){
        document.getElementById('errNewUser').innerHTML = "Username Cannot Be Empty!";
        error = true;
    }else{
        validateDuplicateUser(username, function(duplicateUserValue){
            if(duplicateUserValue){
               document.getElementById('errNewUser').innerHTML = "This username is already taken!";
               error = true; 
            }
        });
    }
    
    if(!email.match(validRegex)){
       document.getElementById('errEmail').innerHTML = "Invalid Email!";
       error = true;
    }

    if(email.trim() === ""){
       document.getElementById('errEmail').innerHTML = "Please Enter Email!";
       error = true;
    }else{
        validateDuplicateEmail(email, function(duplicateEmailValue){
            if(duplicateEmailValue){
               document.getElementById('errEmail').innerHTML = "This email already has been registered!";
               error = true;
            }
        });
    }
    
    
    if(password.trim() === ""){
        document.getElementById('errNewPassword').innerHTML = "Password Cannot Be Empty!";
        error = true;
    }
    
    if(confirmPassword.trim() === ""){
        document.getElementById('errConfirmPassword').innerHTML = "Please Confirm Your Password!";
        error = true;
    }else if(confirmPassword!==password){
        document.getElementById('errConfirmPassword').innerHTML = "Password Not The Same!";
        error = true;
    }
    
    //alert(error);
    return error;
}

//Reset All Error Fields
function registerErrorReset(){
    document.getElementById('errNewUser').innerHTML = "";
    document.getElementById('errEmail').innerHTML = "";
    document.getElementById('errNewPassword').innerHTML = "";
    document.getElementById('errConfirmPassword').innerHTML = "";
}

//Get All Account Records
async function getAllAccountRecords(){
    const options = {
        method: "get",
        headers: myHeaders
    };
    try{
        let response = await fetch(registerUrl+"rows", options);
        //alert(response.status);
        return response;
    }catch(error){
        console.log(error);
    }
}

//Validate Duplicated Email
async function validateDuplicateEmail(emailStr, callback){
    let response = await getAllAccountRecords();
    if(response.status === 200){
        records = await response.json();
        let numberOfRecords = records.count;
        var duplicateValue = 0;
        if(numberOfRecords>0){
            for(i=0;i<numberOfRecords;i++){
                if(records.data[i].email===emailStr){
                    duplicateValue += 1;
                }
            }
        }
        
        if(duplicateValue>0){
            //alert("Duplicate found!");
            duplicateEmailValue = true;
        }else{
            //alert("No Duplicate found!");
            duplicateEmailValue = false;
        }
        
        callback(duplicateEmailValue);
    }
}

//Validate Duplicated Username
async function validateDuplicateUser(userStr, callback){
    let response = await getAllAccountRecords();
    if(response.status === 200){
        records = await response.json();
        let numberOfRecords = records.count;
        var duplicateValue = 0;
        if(numberOfRecords>0){
            for(i=0;i<numberOfRecords;i++){
                if(records.data[i].username===userStr){
                    duplicateValue += 1;
                }
            }
        }
        
        if(duplicateValue>0){
            //alert("Duplicate found!");
            duplicateUserValue = true;
        }else{
            //alert("No Duplicate found!");
            duplicateUserValue = false;
        }
        
        callback(duplicateUserValue);
    }
}

//Create New Account
async function createAccount(){
    if(validateNewAcc() === false){
        let username = document.getElementById("newUser").value;
        let email = document.getElementById("emailAddress").value;
        let password = document.getElementById("newPassword").value;
        
        let updatedata = '{"username" : "'+username+'","password" : "'+password+'","email" : "'+email+'"}';
        //alert(updatedata);
        
        const options = {
            method: "post",
            headers: myHeaders,
            body: updatedata
        };
        try {
            let data = await getAllAccountRecords();
            if (data.status === 200) {
                records = await data.json();
                let numberOfRecords = records.count;
                var duplicateUserValue = 0;
                var duplicateEmailValue = 0;
                if (numberOfRecords > 0) {
                    for (i = 0; i < numberOfRecords; i++) {
                        if (records.data[i].username === username) {
                            duplicateUserValue += 1;
                        } 
                        
                        if(records.data[i].email === email){
                            duplicateEmailValue += 1;
                        }
                    }
                }
                
                if(duplicateUserValue>0){
                    alert('User already exists. Account Creation Failed');
                }else if(duplicateEmailValue>0){
                    alert('Email already registered. Account Creation Failed');
                }else{
                    let response = await fetch(registerUrl, options);
                    //alert(response.status);
                    if (response.status === 201) {
                        alert("Created Account Successfully!");
                        window.open('loginPage.php', '_self');
                    } else {
                        alert('Account Creation Failed');
                    }
                }
            }
        } catch (error) {
            console.log(error);
        }
    }
}

//ACCOUNT LOGIN

//Check Credentials
async function checkCredentials() {
    try {
        let response = await getAllAccountRecords();
        let username = document.getElementById('userName').value;
        let password = document.getElementById('password').value;
        //alert(response.status);
        if (response.status === 200) {
            records = await response.json();
            let numberOfRecords = records.count;
            var invalid = false;
            //alert(records.data[0].username);
            //alert(records.data[0].password);
            if (numberOfRecords > 0) {
                for (i = 0; i < numberOfRecords; i++) {
                    if ((records.data[i].username === username) && (records.data[i].password === password)) {
                        alert('login successful');
                        localStorage.setItem('username',username);
                        window.open('homepage.php', '_self');
                        invalid = false;
                        break;
                    }else{
                        invalid = true;
                    }
                }
                
                if(invalid===true){
                    alert('Invalid username or password');
                }
            }
        }
    } catch (error) {
        console.log(error);
    }
}

//NEW PAGE

//Validate new page details
function validateNewPage() {
    newResetError();
    var error = false;
    let image = document.getElementById("output").getAttribute('src');
    let itemName = document.getElementById("itemName").value;
    let cost = document.getElementById("cost").value;
    let category = document.getElementById("category").value;
    let newCheck = document.getElementById("new");
    let usedCheck = document.getElementById("used");
    let oldCheck = document.getElementById("old");
    let desc = document.getElementById("description").value;
    let meetupCheck = document.getElementById("meetUp");
    let deliveryCheck = document.getElementById("delivery");
    
    if(image===null){
        document.getElementById("errImage").innerHTML = "Please Upload A Image!";
        error = true;
    }
    
    if(itemName.trim()===""){
        document.getElementById("errItemName").innerHTML = "Please Enter A Item Name!";
        error = true;
    }
    
    if(cost.trim()===""){
        document.getElementById("errCost").innerHTML = "Please Enter A Cost!";
        error = true;
    }
    if(category==="select"){
        document.getElementById("errCategory").innerHTML = "Please Select A Category!";
        error = true;
    }
    if(!(newCheck.checked||usedCheck.checked||oldCheck.checked)){
        document.getElementById("errCondition").innerHTML = "Please Choose A Condition Of Your Item!";
        error = true;
    }
    
    if(desc.trim()===""){
        document.getElementById("errDesc").innerHTML = "Please Enter A Description!";
        error = true;
    }
    
    if(!(meetupCheck.checked||deliveryCheck.checked)){
        document.getElementById("errMethod").innerHTML = "Please Choose At Least 1 Dealing Method!";
        error = true;
    }
    return error;
}

function newResetError(){
    document.getElementById("errImage").innerHTML = "";
    document.getElementById("errItemName").innerHTML = "";
    document.getElementById("errCost").innerHTML = "";
    document.getElementById("errCategory").innerHTML = "";
    document.getElementById("errCondition").innerHTML = "";
    document.getElementById("errDesc").innerHTML = "";
    document.getElementById("errMethod").innerHTML = "";
}

//Uses Url to display image
function displayImageFromUrl(imageUrl, imageElementId) {
  fetch(imageUrl)
    .then(response => response.blob())
    .then(blob => {
      var reader = new FileReader();
      reader.onloadend = function() {
        var binaryString = reader.result;
        //alert(btoa(binaryString));
        var imageElement = document.getElementById(imageElementId);
        imageElement.src = 'data:image/jpeg;base64,' + btoa(binaryString);
      };
      reader.readAsBinaryString(blob);
    });
}

//Uses Url to display image
function displayProfilePic(imageUrl, imageElementId) {
  fetch(imageUrl)
    .then(response => response.blob())
    .then(blob => {
      var reader = new FileReader();
      reader.onloadend = function() {
        var binaryString = reader.result;
        var imageDataURI = 'data:image/jpeg;base64,' + btoa(binaryString);
        localStorage.setItem("temp_profileImage", imageDataURI);
        var imageElement = document.getElementById(imageElementId);
        
        imageElement.src = imageDataURI;
        
      };
      reader.readAsBinaryString(blob);
    });
}



//Insert Image testing
async function insertImage(imageUrl){
    fetch(imageUrl)
        .then(response => response.blob())
        .then(blob => {
            var reader = new FileReader();
            reader.onloadend = function () {
                var binaryString = btoa(reader.result);
                lastID += 1;
                let updatedata = '{"id":"' + lastID + '","picdata" : "' + binaryString + '"}';
                const options = {
                    method: "post",
                    headers: myHeaders,
                    body: updatedata
                };   
                fetch(testpic, options)
                    .then(response => {
                        if (response.status === 201) {
                            alert('Insert Successfully');
                        } else {
                            alert('Insert fail');
                        }
                    })
                    .catch(error => {
                        console.error(error);
                        alert('Failed to insert image');
                    });
            };
            reader.readAsBinaryString(blob);
        })
        .catch(error => {
            console.error(error);
            alert('Failed to fetch image');
        });
}

//Get Records Image TestingTable
async function getAllImageRecords(){
    const options = {
        method: "get",
        headers: myHeaders
    };
    try{
        let response = await fetch(testpic+"rows", options);
        //alert(response.status);
        return response;
    }catch(error){
        console.log(error);
    }
}

//Display Image function
async function displayImage(imageElement) {
    try {
        let response = await getAllImageRecords();
        let output = document.getElementById(imageElement);
        //alert(response.status);
        if (response.status === 200) {
            records = await response.json();
            let numberOfRecords = records.count;
            if (numberOfRecords > 0) {
                for (i = 0; i < numberOfRecords; i++) {
                    if (records.data[i].id===1) {
                        alert('Picture Loaded!');
                        //alert(records.data[i].picdata);
                        output.src = 'data:image/jpeg;base64,' + records.data[i].picdata;
                        break;
                    }
                }
            }
        }
    } catch (error) {
        console.log(error);
    }
}

//get all profile image records
async function getAllProfileRecords(){
    const options = {
        method: "get",
        headers: myHeaders
    };
    try{
        let response = await fetch(profileUrl+"rows", options);
        //alert(response.status);
        return response;
    }catch(error){
        console.log(error);
    }
}
//Validate prfile page details
function validateProfilePage() {
    
    var error = false;
    let image = document.getElementById("output").getAttribute('src');
    
    if(image===null){
        document.getElementById("errImage").innerHTML = "Please Upload A Image!";
        error = true;
    }
    return error;
}
//Update Profile image
async function updateImage(user,picID){
    let updatedata = '{"username" : "' + user + '","picdata" : "' + picID +'"}';
    //alert(updatedata);
    const options = {
        method: "post",
        headers: myHeaders,
        body: updatedata
    };
    try{
            let response = await fetch(profileUrl+user,options);
            //alert(response.status);
            if(response.status===201){
                alert('IUpdate Successfully');
            }else{
                //alert('Insert fail');
            }
        }catch(error){
            console.log(error);
        }
}
//Insert Profile Image
async function insertProfileImage(imageUrl) {
    let allData = await getAllProfileRecords();
    if (allData.status === 200) {
        rec = await allData.json();
        var lastID = rec.count;
    }

    if (validateProfilePage() === false) {
        fetch(imageUrl)
                .then(response => response.blob())
                .then(blob => {
                    var reader = new FileReader();
                    reader.onloadend = function () {
                        username = checkUserName();

                        if (username === null) {
                            alert('Please login first!');
                            window.open('loginPage.php', '_self');
                        } else {
                            var create = false;
                            var binaryString = btoa(reader.result);//This is the IMAGE DATA in STRING
                            for (i = 0; i < lastID; i++) {
                                if (rec.data[i].username === checkUserName()) {
                                    //alert("Update");
                                    binaryString = btoa(reader.result);//This is the IMAGE DATA in STRING         
                                    create = false;
                                    break;
                                } else {
                                    //alert('true');
                                    create = true;
                                }
                            }
                            
                            if(lastID===0){
                                create = true;
                            }
                            if (create === true) {
                                //alert("Inserted!");

                                let updatedata = '{"username":"' + username + '","picdata" : "' + binaryString + '"}';

                                const options = {
                                    method: "post",
                                    headers: myHeaders,
                                    body: updatedata
                                };
                                fetch(profileUrl, options)
                                    .then(response => {
                                        if (response.status === 201) {
                                            //alert('Your item is listed!');
                                        } else {
                                            //alert('Insert fail');
                                        }
                                    })
                                    .catch(error => {
                                        console.error(error);
                                        //alert('Failed to insert Record');
                                    });
                            }else{
                                //alert("Updated!");

                                let updatedata = '{"picdata":"' + binaryString  + '"}';

                                const options = {
                                    method: "put",
                                    headers: myHeaders,
                                    body: updatedata
                                };
                                fetch(profileUrl+username, options)
                                    .then(response => {
                                        if (response.status === 201) {
                                            //alert('Your item is updated!');
                                        } else {
                                            //alert('Insert fail');
                                        }
                                    })
                                    .catch(error => {
                                        console.error(error);
                                        //alert('Failed to insert Record');
                                    });
                            }

                        }

                    };
                    reader.readAsBinaryString(blob);
                })
                .catch(error => {
                    console.error(error);
                    //alert('Failed to fetch image');
                });
    }
}

//Display image in profile page
//Display Image function
async function displayProfileImageInProffile(user) {
    try {
        let response = await getAllProfileImageRecords();
        let imageElement = document.getElementById("profile-pic");
        //alert(response.status);
        //alert(user);
        if (response.status === 200) {
            records = await response.json();
            let numberOfRecords = records.count;
            if (numberOfRecords > 0) {
                for (i = 0; i < numberOfRecords; i++) {
                    //alert(records.data[i].username);
                    if (records.data[i].username===user) {
                        //alert('Picture Loaded!');
                        //alert(records.data[i].picdata);
                        var source = 'data:image/jpeg;base64,' + records.data[i].picdata;
                        imageElement.src = source;
                        break;
                    }else{
                        var source = 'https://t4.ftcdn.net/jpg/05/42/36/11/360_F_542361185_VFRJWpR2FH5OiAEVveWO7oZnfSccZfD3.jpg';
                        imageElement.src = source;
                    }
                }
            }
        }
    } catch (error) {
        console.log(error);
    }
}

//Insert Item Record
async function insertItem(imageUrl) {
    let allData = await getAllItemRecords();
    if (allData.status === 200) {
        rec = await allData.json();
        var lastID = rec.count;
    }
            
    if (validateNewPage() === false) {
        fetch(imageUrl)
                .then(response => response.blob())
                .then(blob => {
                    var reader = new FileReader();
                    reader.onloadend = function () {
                        let itemName = document.getElementById("itemName").value;
                        let cost = document.getElementById("cost").value;
                        let category = document.getElementById("category").value;
                        let newCheck = document.getElementById("new");
                        let usedCheck = document.getElementById("used");
                        let oldCheck = document.getElementById("old");
                        let desc = document.getElementById("description").value;
                        let meetupCheck = document.getElementById("meetUp");
                        let deliveryCheck = document.getElementById("delivery");
                        
                        var condition = "";
                        if(newCheck.checked){
                            condition = "new";
                        }else if(usedCheck.checked){
                            condition = "used";
                        }else if(oldCheck.checked){
                            condition = "old";
                        }
                        
                        var method;
                        var lat;
                        var lon;
                        if(meetupCheck.checked&&deliveryCheck){
                            method = "meetDelivery";
                            lat = document.getElementById("Lat").innerHTML;
                            lon = document.getElementById("Lon").innerHTML;
                        }else if(meetupCheck.checked){
                            method = "meet";
                            lat = document.getElementById("Lat").innerHTML;
                            lon = document.getElementById("Lon").innerHTML;
                        }else if(deliveryCheck.checked){
                            method = "delivery";
                            lat = 0;
                            lon = 0;
                        }
                        
                        username = checkUserName();
                        if(username===null){
                            alert('Please login first!');
                            window.open('loginPage.php', '_self');    
                        }else{
                            var sold = 0;
                            var binaryString = btoa(reader.result);//This is the IMAGE DATA in STRING
                       
                            lastID += 1;
                            //alert(lastID);
                            let updatedata = '{"id":"' + lastID + '","category" : "' + category + '","condition" : "' + condition + '","description" : "' + desc + '","lat" : "' + lat + '","lon" : "' + lon + '","method" : "' + method + '","name" : "' + itemName + '","picdata" : "' + binaryString + '","price" : "' + cost + '","sold" : "' + sold + '","username" : "' + username + '"}';
                            //alert(updatedata);
                            const options = {
                                method: "post",
                                headers: myHeaders,
                                body: updatedata
                            };
                            fetch(itemUrl, options)
                                    .then(response => {
                                        if (response.status === 201) {
                                            alert('Your item is listed!');
                                            window.open('ProfilePage.php', '_self');
                                        } else {
                                            //alert('Insert fail');
                                        }
                                    })
                                    .catch(error => {
                                        console.error(error);
                                        //alert('Failed to insert Record');
                                    });
                        }
                        
                    };
                    reader.readAsBinaryString(blob);
                })
                .catch(error => {
                    console.error(error);
                    alert('Failed to fetch image');
                });
    }
}

//Check username
function checkUserName(){
    var username = localStorage.getItem('username');
    return username;
}

//CHAT SYSTEM
//Validate Chat
function validateChat(){
    resetChatError();
    var error = false;
    let message = document.getElementById('message').value;
    if(message.trim()===""){
        document.getElementById('errMessage').innerHTML = "Please enter a message!";
        error = true;
    }
    return error;
}

function resetChatError(){
    document.getElementById('errMessage').innerHTML = "";
}

//Read all Message records from the database
async function getAllMessageRecords(){
    const options = {
        method: "get",
        headers: myHeaders
    };
    try{
        let response = await fetch(messageUrl+"rows", options);
        //alert(response.status);
        return response;
    }catch(error){
        console.log(error);
    }
}

//Insert Message Record Into Database
async function insertMessage() {
    if (validateChat() === false) {
        let message = document.getElementById('message').value;
        let user1 = checkUserName();
        let user2 = localStorage.getItem('seller');
        let groupID = localStorage.getItem('groupid');
        //alert(user1);
        //alert(user2);
        let allData = await getAllMessageRecords();
            if (allData.status === 200) {
                rec = await allData.json();
                var lastID = rec.count;
            }
        lastID += 1;
        let updatedata = '{"id" : "' + lastID + '","message" : "' + message + '","user1" : "' + user1 + '","user2" : "' + user2 +'","groupid" : "' + groupID +'","sender" : "' + user1 +'"}';
        //alert(updatedata);

        const options = {
            method: "post",
            headers: myHeaders,
            body: updatedata
        };
        try {
            let data = await getAllMessageRecords();
            if (data.status === 200) {
                records = await data.json();
                let numberOfRecords = records.count;
                if (numberOfRecords > 0) {
                    for (i = 0; i < numberOfRecords; i++) {
                  

                    }
                }
                let response = await fetch(messageUrl, options);
                //alert(response.status);
                if (response.status === 201) {
                    //alert("Insert Message Successfully!");
                    document.getElementById("message").value = "";
                    loadMessages();
                } else {
                    //alert('Insert Message Failed');
                }
                setTimeout(function () {
                    document.querySelector('#messages-container').scrollTop = document.querySelector('#messages-container').scrollHeight;
                }, 200);

            }
        } catch (error) {
            console.log(error);
        }
    }
}

//load chat
let latestID = 0;

async function loadMessages() {
    let table = document.getElementById('messages');
    let user1 = checkUserName();
    let user2 = localStorage.getItem('seller');
    document.getElementById('user2').innerHTML = user2;
    document.getElementById('title').innerHTML = localStorage.getItem('title');
    let groupID = localStorage.getItem('groupid');
    //alert(groupID);
    try {
        let data = await getAllMessageRecords();
        if (data.status === 200) {
            records = await data.json();
            let numberOfRecords = records.count;
            records.data.sort(function (a, b) {
                return a.id - b.id;
            });
            if (numberOfRecords > 0) {
                for (i = 0; i < numberOfRecords; i++) {
                    if ((((records.data[i].user1 === user1) && (records.data[i].user2 === user2)) || ((records.data[i].user1 === user2) && (records.data[i].user2 === user1))) && (records.data[i].id > latestID)) {
                        latestID = records.data[i].id;

                        var row = document.createElement("tr");
                        var cell = document.createElement("td");
                        var sender = records.data[i].sender;
                        var message = records.data[i].message;
                        var className = (sender === user1) ? "sender" : "receiver";
                        cell.innerHTML = "<span class='" + className + "'>" + sender + ": " + message + "</span>";
                        row.appendChild(cell);
                        table.appendChild(row);
                    }
                }
            }
        }
    } catch (error) {
        console.log(error);
    }
}

async function getAllChatRecords(){
    const options = {
        method: "get",
        headers: myHeaders
    };
    try{
        let response = await fetch(chatUrl+"rows", options);
        //alert(response.status);
        return response;
    }catch(error){
        console.log(error);
    }
}

async function createChat(user1,user2,ID,title){
    let updatedata = '{"groupid" : "' + ID + '","user1" : "' + user1 + '","user2" : "' + user2 +'","title" : "' + title +'"}';
    //alert(updatedata);
    const options = {
        method: "post",
        headers: myHeaders,
        body: updatedata
    };
    try{
            let response = await fetch(chatUrl,options);
            //alert(response.status);
            if(response.status===201){
                //alert('Insert Successfully');
            }else{
                //alert('Insert fail');
            }
        }catch(error){
            console.log(error);
        }
}

async function loadChat() {
    let buyer = checkUserName();
    let title = document.getElementById('itemname').innerHTML;
    let urlParams = new URLSearchParams(window.location.search);
    let seller = urlParams.get("username");
    let updatedata = '{"title" : "' + title + '"}';
    const options = {
        method: "put",
        headers: myHeaders,
        body: updatedata
    };
    try {
        let data = await getAllChatRecords();
        //alert(data.status);
        if (data.status === 200) {
            records = await data.json();
            var create = false;
            let numberOfRecords = records.count;
            lastID = numberOfRecords+1; 
            if (numberOfRecords > 0) {
                for (i = 0; i < numberOfRecords; i++) {
                    if (((records.data[i].user1===buyer)&&(records.data[i].user2===seller))||((records.data[i].user1===seller)&&(records.data[i].user2===buyer))) {
                        //alert('Existing Group Chat');
                        groupid = i+1;
                        let response = await fetch(chatUrl+groupid, options);
                        if(response.status===200){
                            //alert("update successfully");
                        }
                        create = false;
                        break;
                    }else{
                        groupid = lastID;
                        create = true;
                    }
                }
            } else {
                groupid = lastID;
                create = true;
            }
            
            if(create===true){
                createChat(buyer,seller,lastID,title);
            }
            
            localStorage.setItem('seller',seller);
            localStorage.setItem('groupid',groupid);
            localStorage.setItem('title',title);
            window.open('chatsPage.php', '_self');    
        }
    } catch (error) {
        console.log(error);
    }
}

async function getAllProfileImageRecords(){
    const options = {
        method: "get",
        headers: myHeaders
    };
    try{
        let response = await fetch(profileUrl+"rows", options);
        //alert(response.status);
        return response;
    }catch(error){
        console.log(error);
    }
}

//Display Image function
async function displayProfileImage(imageElement,user) {
    try {
        let response = await getAllProfileImageRecords();
        //alert(response.status);
        //alert(user);
        if (response.status === 200) {
            records = await response.json();
            let numberOfRecords = records.count;
            if (numberOfRecords > 0) {
                for (i = 0; i < numberOfRecords; i++) {
                    //alert(records.data[i].username);
                    if (records.data[i].username===user) {
                        //alert('Picture Loaded!');
                        //alert(records.data[i].picdata);
                        var source = 'data:image/jpeg;base64,' + records.data[i].picdata;
                        imageElement.innerHTML = '<img class="output" src='+source+'>';
                        break;
                    }else{
                        var source = 'https://t4.ftcdn.net/jpg/05/42/36/11/360_F_542361185_VFRJWpR2FH5OiAEVveWO7oZnfSccZfD3.jpg';
                        imageElement.innerHTML = '<img class="output" src='+source+'>';
                    }
                }
            }
        }
    } catch (error) {
        console.log(error);
    }
}

async function loadChatList(){
    let localUser = checkUserName();
    let table = document.getElementById('table');
    try {
        let data = await getAllChatRecords();
        if (data.status === 200) {
            records = await data.json();
            let numberOfRecords = records.count;
            if (numberOfRecords > 0) {
                for (i = 0; i < numberOfRecords; i++) {
                    if((records.data[i].user1===localUser)||(records.data[i].user2===localUser)){
                        var textReceiver;
                        var title =  records.data[i].title;
                        var groupid = records.data[i].groupid;
                        if(records.data[i].user1===localUser){
                            textReceiver = records.data[i].user2;
                        }else{
                            textReceiver = records.data[i].user1;
                        }
                        var row = document.createElement("tr");
                        var cell = document.createElement("td");
                        var cell1 = document.createElement("td");
                        var cell2 = document.createElement("td");
                        displayProfileImage(cell,textReceiver);
                        cell1.innerHTML = cell1.innerHTML = textReceiver;
                        cell2.innerHTML = title;
                        row.appendChild(cell);
                        row.appendChild(cell1);
                        row.appendChild(cell2);        
                        row.addEventListener("click", (function (textReceiver, title) {
                            return function () {
                                localStorage.setItem('seller', textReceiver);
                                localStorage.setItem('groupid', groupid);
                                localStorage.setItem('title', title);
                                chatIframe = document.getElementById('chatIframe');
                                chatIframe.src = "chatSys.php";
                            }
                        })(textReceiver, title));
                        table.appendChild(row);
                    }
                }
            }else{
                //Display message to ask someone to buy item
            }
        }
    } catch (error) {
        console.log(error);
    }
}




//Display Messages


//Get Item Data
async function getAllItemRecords(){
    const options = {
        method: "get",
        headers: myHeaders
    };
    try{
        let response = await fetch(itemUrl+"rows", options);
        //alert(response.status);
        return response;
    }catch(error){
        console.log(error);
    }
}

async function getAllLikedRecords(){
    const options = {
        method: "get",
        headers: myHeaders
    };
    try{
        let response = await fetch(likedUrl+"rows", options);
        //alert(response.status);
        return response;
    }catch(error){
        console.log(error);
    }
}

//updates like record
async function updateLikedRecord(id, liked){
    let updatedata = '{"like" : "' + liked + '"}';
    const options = {
        method: "put",
        headers: myHeaders,
        body: updatedata
    };
    try{
        let response = await fetch(likedUrl+id, options);
        //alert(response.status);
    }catch(error){
        console.log(error);
    }
}

async function getAllItemRecords1(){
    const options = {
        method: "get",
        headers: myHeaders
    };
    try{
        let response = await fetch(itemUrl+"rows", options);
        //alert(response.status);
        return response;
    }catch(error){
        console.log(error);
    }
}

async function createLike(user, ID){
    
    let getlikes = await getAllLikedRecords();
    if(getlikes.status === 200) {
        like = await getlikes.json();
        var lastID = like.count;
    }
    
    lastID = lastID + 1;
    
    let updatedata = '{"id" : "' + lastID + '","itemid" : "' + ID + '","username" : "' + user +'","like" : "' + 1 +'"}';
    //alert(updatedata);
    const options = {
        method: "post",
        headers: myHeaders,
        body: updatedata,
    };
    try{
            let response = await fetch(likedUrl,options);
            //alert(response.status);
            if(response.status===201){
                //alert('Insert Successfully');
            }else{
                //alert('Insert fail');
            }
        }catch(error){
            console.log(error);
        }
}

//check if an item is liked or not
async function checkifliked(user, ID){
    try {
        let response = await getAllLikedRecords();
        if (response.status === 200){
           likes = await response.json();
           let numberoflikes = likes.count;
           if (numberoflikes>0){
               for(h = 0; h < numberoflikes; h++) {
                   if (user == likes.data[h].username && ID == likes.data[h].id)
                   {
                       return true;
                   }
               }
                return false;
           } else {
                return false;}
        }
    } catch (error) {
        console.log(error);
    }
}

//check if item is liked or unliked then make changes accordingly to database and button
async function likeorunlike(user, ID, i){
    //alert("like or unlike working");
    likeBtn = document.getElementById(i);
    try {
        let response = await getAllLikedRecords();
        if (response.status === 200){
           like = await response.json();
           let numberoflikes = like.count;
           if (numberoflikes>0){
               for(h = 0; h < numberoflikes; h++) {
                   if (user == like.data[h].username && ID == like.data[h].itemid)
                   {
                       if(like.data[h].like == 1){
                            likeBtn.innerHTML = 'Add To Liked';
                            updateLikedRecord(like.data[h].id, 0);
                       return true;
                       } else if(like.data[h].like == 0){
                            likeBtn.innerHTML = 'Remove From Liked';
                            updateLikedRecord(like.data[h].id, 1);
                       return true;
                       } else {
                           alert("error in update, reload home page");
                       }
                    }
                }
                createLike(user, ID);
                //alert("liked created successfully");
                likeBtn.innerHTML = 'Remove From Liked';
                return false;
            } else {
                createLike(user, ID);
                //alert("liked created successfully");
                likeBtn.innerHTML = 'Remove From Liked';
                return false;
            }
        } else {alert("error connecting to db");}
    } catch (error) {
        console.log(error);
    }
}

//Load Home Page items
async function loadItemsHomepage() {
    let searchbutton = document.getElementById("searchbtn");
    let navuser = document.getElementById("navuser");
    navuser.innerHTML = "Welcome Back " + checkUserName();
    searchbutton.addEventListener("click", () => holdsearchdata()) ;
    try {
        let response = await getAllItemRecords();
        if (response.status === 200) {
            records = await response.json();
            let numberOfRecords = records.count;
            if (numberOfRecords > 0) {
                let uniqueNumbers = new Set();

                while (uniqueNumbers.size < 6) {
                    let randomNumber = Math.floor(Math.random() * numberOfRecords);
                    uniqueNumbers.add(randomNumber);
                }

                randomarray = Array.from(uniqueNumbers);
                for (u = 0; u < 6; u++) {
                    i = randomarray[u];
                    if(records.data[i].sold==0){
                    let cardContainer = document.createElement("div");
                    cardContainer.classList.add("col-lg-4");
                    
                    let ID = records.data[i].id;
                    let username = records.data[i].username;

                    let trainerItem = document.createElement("div");
                    trainerItem.classList.add("trainer-item");
                    trainerItem.addEventListener("click", () => holditemdata(ID,username) );

                    let imageThumb = document.createElement("div");
                    imageThumb.classList.add("image-thumb");

                    let image = document.createElement("img");
                    image.src = 'data:image/jpeg;base64,' + records.data[i].picdata;
                    image.style.width = "300px";
                    image.style.height = "300px";
                    image.alt = records.data[i].name;
                    imageThumb.appendChild(image);
                    trainerItem.appendChild(imageThumb);

                    let downContent = document.createElement("div");
                    downContent.classList.add("down-content");

                    let price = document.createElement("span");
                    price.innerHTML = "$"+records.data[i].price;

                    let title = document.createElement("h4");
                    title.innerHTML = records.data[i].name;

                    let description = document.createElement("p");
                    description.innerHTML = records.data[i].description;
                    downContent.appendChild(price);
                    downContent.appendChild(title);

                    let socialIcons = document.createElement("ul");
                    socialIcons.classList.add("social-icons");

                    let likeBtn = document.createElement("li");

                    let likeBtnElem = document.createElement("button");
                        let likebtnstring = "likeBtn"+ ID;
                        likeBtnElem.id = likebtnstring
                        
                        let data = await getAllLikedRecords();
                        if (data.status === 200) {
                            records1 = await data.json();
                            numberofrec = records1.count;
                            if(numberofrec>0){
                                for(r=0;r<numberofrec;r++){
                                    if((records1.data[r].itemid === ID)&&(records1.data[r].username===checkUserName())&&(records1.data[r].like===1)){
                                        likeBtnElem.innerHTML = 'Remove from Liked';
                                        break;
                                    }else{
                                        likeBtnElem.innerHTML = 'Add to Liked';
                                    }
                                }
                            }else{
                                likeBtnElem.innerHTML = 'Add to Liked';
                            }
                        }
                                
                        likeBtnElem.addEventListener("click", (event) => {
                            likeorunlike(checkUserName(), ID, likebtnstring)
                            event.stopPropagation();
                        });
                    
                    
                    likeBtn.appendChild(likeBtnElem);
                    socialIcons.appendChild(likeBtn);
                    downContent.appendChild(socialIcons);
                    trainerItem.appendChild(downContent);
                    cardContainer.appendChild(trainerItem);

                    let targetDiv = document.querySelector("#featureditems");
                    targetDiv.appendChild(cardContainer);
                    }
                }

                username = checkUserName();
                if (username === null) {
                    alert('Please login first!');
                    window.open('loginPage.php', '_self');
                } else {

                }
            }
        }

    } catch (error) {
        console.log(error);
    }

}

//holds data for item click and opens the new indiv item page
function holditemdata(id, username){   
    window.open(`itempage.php?data=${id}&username=${username}`, "_self");
}

function holdsearchdata(){   
    let searching = document.getElementById("searchInput").value;
    window.open(`searchpage.php?search=${searching}`, "_self");
}

//function for onload of itempage
async function loaditempage(){
    let urlParams = new URLSearchParams(window.location.search);
    let data1 = urlParams.get("data");
    let username = urlParams.get("username");
    
    //alert(data1);
    //alert(username);
    
    try {
        let response = await getAllItemRecords1();
        if (response.status === 200) {
            let record = await response.json();
            let numberOfRecords = record.count;
            for (p = 0; p < numberOfRecords; p++){
                if (data1 == record.data[p].id){
                    document.getElementById("chatbutton").style.setProperty('display', 'initial');
                    document.getElementById("itemname").innerHTML = record.data[p].name;
                    document.getElementById("itemcategory").innerHTML = "Category: " + record.data[p].category;
                    document.getElementById("itemdesc").innerHTML = record.data[p].description; 
                    document.getElementById("itemcondition").innerHTML = record.data[p].condition;
                    document.getElementById("itemprice").innerHTML = record.data[p].price;
                    let userDisplayElement = document.getElementById("user");
                    userDisplayElement.innerHTML = "Sold By User: " + record.data[p].username;
                    let current_username = record.data[p].username;
                    userDisplayElement.addEventListener('click', function() {
                        localStorage.setItem("SellerUsername",current_username);
                        //alert(localStorage.getItem("SellerUsername"));
                      
                        window.open('SellerProfile.php', '_self');
                    });
                    let ways = record.data[p].method;
                    if (ways == "meetDelivery")
                    {
                        document.getElementById("itemdeliverystatus").className = "checked";
                        document.getElementById("itemmeetupstatus").className = "checked";
                        document.getElementById("maplabel").innerHTML = "Meet Up Location:";
                        let itemlat = record.data[p].lat;
                        let itemlon = record.data[p].lon;
                        let maplink = "https://maps.google.com/maps?q=" + itemlat + "," + itemlon + "&output=embed";
                        document.getElementById("map").setAttribute('src', maplink);
                        document.getElementById("mapdiv").removeAttribute('hidden');

                    } else if (ways == "meet")
                    {
                        document.getElementById("itemdeliverystatus").className = "unchecked";
                        document.getElementById("itemmeetupstatus").className = "checked";
                        document.getElementById("maplabel").innerHTML = "Meet Up Location:";
                        let itemlat = record.data[p].lat;
                        let itemlon = record.data[p].lon;
                        let maplink = "https://maps.google.com/maps?q=" + itemlat + "," + itemlon + "&output=embed";
                        document.getElementById("map").setAttribute('src', maplink);
                        document.getElementById("mapdiv").removeAttribute('hidden');

                    } else if (ways == "delivery")
                    {
                        document.getElementById("itemdeliverystatus").className = "checked";
                        document.getElementById("itemmeetupstatus").className = "unchecked";

                    } else {
                        alert("Error Getting Methods");
                    }
                    var img = document.getElementById("itempicture");
                    img.src = 'data:image/jpeg;base64,' + record.data[p].picdata;
                    if (record.data[p].username == checkUserName()) {
                        document.getElementById("chatbutton").style.setProperty('display', 'none');
                    }
                } else {}
            }
        }
    } catch (error) {
        console.error(error);
    }
}

// Initialize and add the map
function initMap(itemlat, itemlon) {
                let location = {lat: itemlat, lon: itemlon};
                let map = new google.maps.Map(document.getElementById("map"), {zoom: 4, center: location});
                let marker = new google.maps.Marker({position: location, map: map});
}


//load electronics category page
async function loadItemsCategoryspage() {
    try {
        let response = await getAllItemRecords();
        if (response.status === 200) {
            cat = await response.json();
            let numberOfRecords = cat.count;
            let isLikeBtnClicked = false;
            let categorydata = document.getElementById('helper').getAttribute('data-name');
            if (numberOfRecords > 0) {
                for (k = 0; k < numberOfRecords; k++) {
                    if (cat.data[k].sold == 0 && cat.data[k].category == categorydata) {
                        let cardContainer = document.createElement("div");
                        cardContainer.classList.add("col-lg-4");

                        let ID = cat.data[k].id;
                        let username = cat.data[k].username;

                        let trainerItem = document.createElement("div");
                        trainerItem.classList.add("trainer-item");
                        trainerItem.addEventListener("click", (event) => {
                            if (!isLikeBtnClicked) {
                                holditemdata(ID, username);
                            }
                        });


                        let imageThumb = document.createElement("div");
                        imageThumb.classList.add("image-thumb");

                        let image = document.createElement("img");
                        image.src = 'data:image/jpeg;base64,' + cat.data[k].picdata;
                        image.style.width = "300px";
                        image.style.height = "300px";
                        image.alt = cat.data[k].name;
                        imageThumb.appendChild(image);
                        trainerItem.appendChild(imageThumb);

                        let downContent = document.createElement("div");
                        downContent.classList.add("down-content");

                        let price = document.createElement("span");
                        price.innerHTML = "$"+cat.data[k].price;

                        let title = document.createElement("h4");
                        title.innerHTML = cat.data[k].name;

                        let description = document.createElement("p");
                        description.innerHTML = cat.data[k].description;
                        downContent.appendChild(price);
                        downContent.appendChild(title);

                        let socialIcons = document.createElement("ul");
                        socialIcons.classList.add("social-icons");

                        let likeBtn = document.createElement("li");

                        let likeBtnElem = document.createElement("button");
                        let likebtnstring = "likeBtn"+ ID;
                        likeBtnElem.id = likebtnstring
                        
                        let data = await getAllLikedRecords();
                        if (data.status === 200) {
                            records = await data.json();
                            numberofrec = records.count;
                            if(numberofrec>0){
                                for(i=0;i<numberofrec;i++){
                                    if((records.data[i].itemid === ID)&&(records.data[i].username===checkUserName())&&(records.data[i].like===1)){
                                        likeBtnElem.innerHTML = 'Remove from Liked';
                                        break;
                                    }else{
                                        likeBtnElem.innerHTML = 'Add to Liked';
                                    }
                                }
                            }else{
                                likeBtnElem.innerHTML = 'Add to Liked';
                            }
                        }
                                
                        likeBtnElem.addEventListener("click", (event) => {
                            likeorunlike(checkUserName(), ID, likebtnstring)
                            event.stopPropagation();
                        });

                        likeBtn.appendChild(likeBtnElem);
                        socialIcons.appendChild(likeBtn);
                        downContent.appendChild(socialIcons);
                        trainerItem.appendChild(downContent);
                        cardContainer.appendChild(trainerItem);

                        let targetDiv = document.querySelector("#electronicitems");
                        targetDiv.appendChild(cardContainer);
                    } else {
                    }
                }

                username = checkUserName();
                if (username === null) {
                    alert('Please login first!');
                    window.open('loginPage.php', '_self');
                } else {

                }
            }
        }

    } catch (error) {
        console.log(error);
    }

}


async function search() {
    let urlParams = new URLSearchParams(window.location.search);
    let searching = urlParams.get("search");
    
    document.getElementById("showsearch").innerHTML = "Showing Listings Related To " + searching;
    
    let searching1 = searching.charAt(0).toUpperCase() + searching.slice(1);
    let searching2 = searching.charAt(0).toLowerCase() + searching.slice(1);
    
    try {
        let response = await getAllItemRecords();
        if (response.status === 200) {
            se = await response.json();
            let numberOfRecords = se.count;
            if (numberOfRecords > 0) {
                for (l = 0; l < numberOfRecords; l++) {
                    if (se.data[l].sold == 0 && (se.data[l].category.includes(searching1) || se.data[l].category.includes(searching2) || se.data[l].name.includes(searching1)  || se.data[l].name.includes(searching2)) ) {
                        let cardContainer = document.createElement("div");
                        cardContainer.classList.add("col-lg-4");

                        let ID = se.data[l].id;
                        let username = se.data[l].username;

                        let trainerItem = document.createElement("div");
                        trainerItem.classList.add("trainer-item");
                        trainerItem.addEventListener("click", () => holditemdata(ID, username));

                        let imageThumb = document.createElement("div");
                        imageThumb.classList.add("image-thumb");

                        let image = document.createElement("img");
                        image.src = 'data:image/jpeg;base64,' + se.data[l].picdata;
                        image.style.width = "300px";
                        image.style.height = "300px";
                        image.alt = se.data[l].name;
                        imageThumb.appendChild(image);
                        trainerItem.appendChild(imageThumb);

                        let downContent = document.createElement("div");
                        downContent.classList.add("down-content");

                        let price = document.createElement("span");
                        price.innerHTML = "$"+se.data[l].price;

                        let title = document.createElement("h4");
                        title.innerHTML = se.data[l].name;

                        let description = document.createElement("p");
                        description.innerHTML = se.data[l].description;
                        downContent.appendChild(price);
                        downContent.appendChild(title);

                        let socialIcons = document.createElement("ul");
                        socialIcons.classList.add("social-icons");

                        let likeBtn = document.createElement("li");

                        let likeBtnElem = document.createElement("button");
                        let likebtnstring = "likeBtn"+ ID;
                        likeBtnElem.id = likebtnstring
                        
                        let data = await getAllLikedRecords();
                        if (data.status === 200) {
                            records = await data.json();
                            numberofrec = records.count;
                            if(numberofrec>0){
                                for(i=0;i<numberofrec;i++){
                                    if((records.data[i].itemid === ID)&&(records.data[i].username===checkUserName())&&(records.data[i].like===1)){
                                        likeBtnElem.innerHTML = 'Remove from Liked';
                                        break;
                                    }else{
                                        likeBtnElem.innerHTML = 'Add to Liked';
                                    }
                                }
                            }else{
                                likeBtnElem.innerHTML = 'Add to Liked';
                            }
                        }
                                
                        likeBtnElem.addEventListener("click", (event) => {
                            likeorunlike(checkUserName(), ID, likebtnstring)
                            event.stopPropagation();
                        });

                        likeBtn.appendChild(likeBtnElem);
                        socialIcons.appendChild(likeBtn);
                        downContent.appendChild(socialIcons);
                        trainerItem.appendChild(downContent);
                        cardContainer.appendChild(trainerItem);

                        let targetDiv = document.querySelector("#featureditems");
                        targetDiv.appendChild(cardContainer);
                    } else {
                    }
                }

                username = checkUserName();
                if (username === null) {
                    alert('Please login first!');
                    window.open('loginPage.php', '_self');
                } else {

                }
            }
        }

    } catch (error) {
        console.log(error);
    }

}

//load items for all category page
async function loadItemsAllpage() {
    try {
        let response = await getAllItemRecords();
        if (response.status === 200) {
            records = await response.json();
            let numberOfRecords = records.count;
            if (numberOfRecords > 0) {
                for (i = 0; i < numberOfRecords; i++) {
                    if(records.data[i].sold==0){
                    let cardContainer = document.createElement("div");
                    cardContainer.classList.add("col-lg-4");
                    
                    let ID = records.data[i].id;
                    let username = records.data[i].username;

                    let trainerItem = document.createElement("div");
                    trainerItem.classList.add("trainer-item");
                    trainerItem.addEventListener("click", () => holditemdata(ID,username) );

                    let imageThumb = document.createElement("div");
                    imageThumb.classList.add("image-thumb");

                    let image = document.createElement("img");
                    image.src = 'data:image/jpeg;base64,' + records.data[i].picdata;
                    image.style.width = "300px";
                    image.style.height = "300px";
                    image.alt = records.data[i].name;
                    imageThumb.appendChild(image);
                    trainerItem.appendChild(imageThumb);

                    let downContent = document.createElement("div");
                    downContent.classList.add("down-content");

                    let price = document.createElement("span");
                    price.innerHTML = "$"+records.data[i].price;

                    let title = document.createElement("h4");
                    title.innerHTML = records.data[i].name;

                    let description = document.createElement("p");
                    description.innerHTML = records.data[i].description;
                    downContent.appendChild(price);
                    downContent.appendChild(title);

                    let socialIcons = document.createElement("ul");
                    socialIcons.classList.add("social-icons");

                    let likeBtn = document.createElement("li");

                    let likeBtnElem = document.createElement("button");
                        let likebtnstring = "likeBtn"+ ID;
                        likeBtnElem.id = likebtnstring
                        
                        let data = await getAllLikedRecords();
                        if (data.status === 200) {
                            records1 = await data.json();
                            numberofrec = records1.count;
                            if(numberofrec>0){
                                for(u=0;u<numberofrec;u++){
                                    if((records1.data[u].itemid === ID)&&(records1.data[u].username===checkUserName())&&(records1.data[u].like===1)){
                                        likeBtnElem.innerHTML = 'Remove from Liked';
                                        break;
                                    }else{
                                        likeBtnElem.innerHTML = 'Add to Liked';
                                    }
                                }
                            }else{
                                likeBtnElem.innerHTML = 'Add to Liked';
                            }
                        }
                                
                        likeBtnElem.addEventListener("click", (event) => {
                            likeorunlike(checkUserName(), ID, likebtnstring)
                            event.stopPropagation();
                        });

                    likeBtn.appendChild(likeBtnElem);
                    socialIcons.appendChild(likeBtn);
                    downContent.appendChild(socialIcons);
                    trainerItem.appendChild(downContent);
                    cardContainer.appendChild(trainerItem);

                    let targetDiv = document.querySelector("#featureditems");
                    targetDiv.appendChild(cardContainer);
                    }
                }

                username = checkUserName();
                if (username === null) {
                    alert('Please login first!');
                    window.open('loginPage.php', '_self');
                } else {

                }
            }
        }

    } catch (error) {
        console.log(error);
    }

}

//load electronics category page
async function loadLikedpage() {
    try {

        let response1 = await getAllLikedRecords();
        if (response1.status === 200) {
        likes = await response1.json();
        let numberoflikes = likes.count;
        
        
        let response = await getAllItemRecords();
        if (response.status === 200) {
            cat = await response.json();
            let numberOfRecords = cat.count;
            let isLikeBtnClicked = false;
            let categorydata = document.getElementById('helper').getAttribute('data-name');
            if (numberOfRecords > 0) {
                for (k = 0; k < numberOfRecords; k++) {
                    for(j=0; j<numberoflikes; j++){
                        if (cat.data[k].sold == 0 && likes.data[j].username == checkUserName() && cat.data[k].id == likes.data[j].itemid && likes.data[j].like == 1) {
                        let cardContainer = document.createElement("div");
                        cardContainer.classList.add("col-lg-4");

                        let ID = cat.data[k].id;
                        let username = cat.data[k].username;

                        let trainerItem = document.createElement("div");
                        trainerItem.classList.add("trainer-item");
                        trainerItem.addEventListener("click", (event) => {
                            if (!isLikeBtnClicked) {
                                holditemdata(ID, username);
                            }
                        });


                        let imageThumb = document.createElement("div");
                        imageThumb.classList.add("image-thumb");

                        let image = document.createElement("img");
                        image.src = 'data:image/jpeg;base64,' + cat.data[k].picdata;
                        image.style.width = "300px";
                        image.style.height = "300px";
                        image.alt = cat.data[k].name;
                        imageThumb.appendChild(image);
                        trainerItem.appendChild(imageThumb);

                        let downContent = document.createElement("div");
                        downContent.classList.add("down-content");

                        let price = document.createElement("span");
                        price.innerHTML = "$"+cat.data[k].price;

                        let title = document.createElement("h4");
                        title.innerHTML = cat.data[k].name;

                        let description = document.createElement("p");
                        description.innerHTML = cat.data[k].description;
                        downContent.appendChild(price);
                        downContent.appendChild(title);

                        let socialIcons = document.createElement("ul");
                        socialIcons.classList.add("social-icons");

                        let likeBtn = document.createElement("li");
                        
                        let likeBtnElem = document.createElement("button");
                        let likebtnstring = "likeBtn"+ ID;
                        likeBtnElem.id = likebtnstring
                        
                        let data = await getAllLikedRecords();
                        if (data.status === 200) {
                            records = await data.json();
                            numberofrec = records.count;
                            if(numberofrec>0){
                                for(i=0;i<numberofrec;i++){
                                    if((records.data[i].itemid === ID)&&(records.data[i].username===checkUserName())&&(records.data[i].like===1)){
                                        likeBtnElem.innerHTML = 'Remove from Liked';
                                        break;
                                    }else{
                                        likeBtnElem.innerHTML = 'Add to Liked';
                                    }
                                }
                            }else{
                                likeBtnElem.innerHTML = 'Add to Liked';
                            }
                        }
                                
                        likeBtnElem.addEventListener("click", (event) => {
                            likeorunlike(checkUserName(), ID, likebtnstring);
                            event.stopPropagation();
                        });
                        
                        likeBtn.appendChild(likeBtnElem);
                        socialIcons.appendChild(likeBtn);
                        downContent.appendChild(socialIcons);
                        trainerItem.appendChild(downContent);
                        cardContainer.appendChild(trainerItem);

                        let targetDiv = document.querySelector("#electronicitems");
                        targetDiv.appendChild(cardContainer);
                    } else {
                    }
                    }
                }

                username = checkUserName();
                if (username === null) {
                    alert('Please login first!');
                    window.open('loginPage.php', '_self');
                } else {

                }
            }
        }

    }

}catch (error) {
        console.log(error);
    }
}

async function DisplaymyItemDetails(itemId){
    try{
        let response = await getAllItemRecords();
        if (response.status === 200) {
            records = await response.json();
            //alert(records.data[2].price)
            
            document.getElementById("image").src = 'data:image/jpeg;base64,' + records.data[itemId].picdata;
            document.getElementById("name").innerHTML = records.data[itemId].name;
            document.getElementById("description").innerHTML = records.data[itemId].description;
            document.getElementById("price").innerHTML = records.data[itemId].price;
            document.getElementById("condition").innerHTML = records.data[itemId].condition;
            
            
        }
    } catch(error){
        console.log(error);
    }
}


function EditPriceError() {
    document.getElementById("errEdit").innerHTML = "";
}

//Validate Edit Price details
function validateEditPrice() {
    EditPriceError();
    let error = false;
    
    let EditPrice = document.getElementById("EditPrice").value.trim();
    
    if (!EditPrice) {
        document.getElementById("errEdit").innerHTML = "Please Enter A Valid Price!";
        error = true;
    }
    
    return error;
}


let updatedItem = {};

async function EditItemPrice() {
    if (validateEditPrice()) {
        return;
    }

    let itemId = new URLSearchParams(window.location.search).get("itemId");
    let price = parseFloat(document.getElementById("EditPrice").value);
    let username = checkUserName();
    
    //alert(records.data[6].price)
    //alert(records.data[20].id)
    
    
   
    
    let updatedRecord = {
        price: price
    };
    console.log(itemUrl + "/" + itemId);
    try {
        let response = await fetch(itemUrl  + records.data[itemId].id, {
            method: "put",
            headers: myHeaders,
            body: JSON.stringify(updatedRecord)
        });
        if (response.status === 200) {
            updatedItem = await response.json();
            document.getElementById("price").innerHTML = updatedItem.data.price;
            
          
            alert("Price updated successfully");
        } else {
            alert("Failed to update price");
        }
    } catch (error) {
        console.error(error);
        alert("Failed to update price");
    }

    // Update the stored item data with the updated values
    let response = await getAllItemRecords();
    if (response.status === 200) {
        let responseJson = await response.json();
        records = responseJson;
        records.data.forEach(item => {
            
            if (item.id === itemId && item.username === username) {
                item.price = updatedItem.data.price;
                
            }
        });
    }
    
    //alert(records.data[12].username)
    //alert(records.data[12].price)






//console.log("updated item data: ", updatedItem);
//console.log(await response.json());
//console.log(response.status);
}



async function DisplayVerification(){
 try {
        let response = await getAllItemRecords();
        //alert(response.status);
        if (response.status === 200) {
            records = await response.json();
            let numberOfRecords = records.count;
            //alert(records.data[0].picdata);
            //alert(records.data[0].name);
            
            let username = checkUserName();
            
            
            no_sold = 0;
            for (i = 0; i < numberOfRecords; i++){
                if (records.data[i].username===username && records.data[i].sold === 1 ){
                    no_sold++;
                }
            }
            localStorage.setItem('sold',no_sold);
            
            
            
            if(no_sold > 10){
                
                var iconContainer = document.getElementById("verification");
                iconContainer.innerHTML = '<i class="fa fa-check verified-icon"></i>';
            }
            
            //document.getElementById("numberOfsold").innerHTML = no_sold;
     
            //alert(records.data[2].price)

        }
    } catch (error) {
        console.log(error);
    }

}

async function DisplaySellerVerification(){
 try {
        let response = await getAllItemRecords();
        //alert(response.status);
        if (response.status === 200) {
            records = await response.json();
            let numberOfRecords = records.count;
            //alert(records.data[0].picdata);
            //alert(records.data[0].name);
            
            let sellername = localStorage.getItem("SellerUsername");
            
            
            no_sold = 0;
            for (i = 0; i < numberOfRecords; i++){
                if (records.data[i].username===sellername && records.data[i].sold === 1 ){
                    no_sold++;
                }
            }
            localStorage.setItem('sold',no_sold);
            
            
            
            if(no_sold > 10){
                
                var iconContainer = document.getElementById("verification");
                iconContainer.innerHTML = '<i class="fa fa-check verified-icon"></i>';
            }
            
            //document.getElementById("numberOfsold").innerHTML = no_sold;
     
            //alert(records.data[2].price)

        }
    } catch (error) {
        console.log(error);
    }

}




async function getAllItemDisplay() {
    try {
            let response = await getAllItemRecords();
            if (response.status === 200) {
                
                let records = await response.json();
                let numberOfRecords = records.count;
                
                
            
            //alert(response.status);
       
            //alert(records.data[0].picdata);
            //alert(records.data[0].name);
            
            let username = checkUserName();
            no_list = 0;
            for (i = 0; i < numberOfRecords; i++){
                if (records.data[i].username===username){
                    no_list++;
                }
            }
            
            no_sold = 0;
            for (i = 0; i < numberOfRecords; i++){
                if (records.data[i].username===username && records.data[i].sold === 1 ){
                    no_sold++;
                }
            }
            localStorage.setItem('sold',no_sold);
            
            
            
            if(no_sold > 10){
                
                var iconContainer = document.getElementById("verification");
                iconContainer.innerHTML = '<i class="fa fa-check verified-icon"></i>';
                
            }
            
            document.getElementById("numberOfsold").innerHTML = no_sold;
            document.getElementById("numberOflistings").innerHTML = no_list;
            
            
          
            
            
           
            //alert(records.data[2].price)

            if (numberOfRecords > 0) {
                for (i = 0; i < numberOfRecords; i++) {
                    //return records.data[i]; 


                    if (records.data[i].username===username) {
                        //alert(i);
                        //alert(records.data[i].picdata);
                        if (records.data[i].sold === 0){
                            let cardContainer = document.createElement("div");
                            cardContainer.classList.add("col-lg-4");
                            cardContainer.addEventListener("click", (function (i) {
                                return function () {
                                    //alert(i);

                                    window.location.href = "myItemDetails.php?itemId=" + i;
                                };
                            })(i));


                            let card = document.createElement("div");
                            card.classList.add("card", "shadow-sm");


                            let username = records.data[i].username;

                            let trainerItem = document.createElement("div");
                            trainerItem.classList.add("trainer-item");


                            let imageThumb = document.createElement("div");
                            imageThumb.classList.add("image-thumb");

                            let image = document.createElement("img");
                            image.src = 'data:image/jpeg;base64,' + records.data[i].picdata;
                            image.style.width = "320px";
                            image.style.height = "300px";
                            image.alt = records.data[i].name;
                            imageThumb.appendChild(image);
                            trainerItem.appendChild(imageThumb);

                            let downContent = document.createElement("div");
                            downContent.classList.add("down-content");

                            let price = document.createElement("span");
                            price.innerHTML = "$" + records.data[i].price;

                            let title = document.createElement("h4");
                            title.innerHTML = records.data[i].name;

                            let description = document.createElement("p");
                            description.innerHTML = records.data[i].description;
                            downContent.appendChild(price);
                            downContent.appendChild(title);

                            let socialIcons = document.createElement("ul");
                            socialIcons.classList.add("social-icons");

                            
                           

                            
                            
                            downContent.appendChild(socialIcons);
                            trainerItem.appendChild(downContent);
                            cardContainer.appendChild(trainerItem);

                            targetDiv = document.querySelector("#myitems").appendChild(cardContainer);
                        }else{
                            
                            let cardContainer = document.createElement("div");
                            cardContainer.classList.add("col-lg-4");
                            let card = document.createElement("div");
                            card.classList.add("card", "shadow-sm");

                            let username = records.data[i].username;

                            let trainerItem = document.createElement("div");
                            if (records.data[i].sold === 1) {
                               trainerItem.classList.add("sold");
                                let soldMessage = document.createElement("p");
                                soldMessage.innerHTML = "SOLD";
                                soldMessage.style.color = "red";
                                soldMessage.style.position = "absolute";
                                soldMessage.style.top = "50%";
                                soldMessage.style.left = "50%";
                                soldMessage.style.transform = "translate(-50%, -50%)";
                                soldMessage.style.fontWeight = "bold";
                                soldMessage.style.zIndex = "1";
                                trainerItem.appendChild(soldMessage);
                                trainerItem.classList.add("trainer-item");

                                let imageThumb = document.createElement("div");
                                imageThumb.classList.add("image-thumb");

                                let image = document.createElement("img");
                                image.src = 'data:image/jpeg;base64,' + records.data[i].picdata;
                               image.style.width = "300px";
                                image.style.height = "300px";
                                image.alt = records.data[i].name;
                                imageThumb.appendChild(image);
                                trainerItem.appendChild(imageThumb);

                                let downContent = document.createElement("div");
                                downContent.classList.add("down-content");

                                let price = document.createElement("span");
                                price.innerHTML = "$" + records.data[i].price;

                                let title = document.createElement("h4");
                                title.innerHTML = records.data[i].name;

                                let description = document.createElement("p");
                                description.innerHTML = records.data[i].description;
                                downContent.appendChild(price);
                                downContent.appendChild(title);

                                let socialIcons = document.createElement("ul");
                                socialIcons.classList.add("social-icons");

                                let likeBtn = document.createElement("li");

                                                                
                                downContent.appendChild(socialIcons);
                                trainerItem.appendChild(downContent);
                                cardContainer.appendChild(trainerItem);

                                targetDiv = document.querySelector("#myitems").appendChild(cardContainer);
                            }
                            

                        }
                    
                    }


                    username = checkUserName();
                    if (username === null) {
                        alert('Please login first!');
                        window.open('loginPage.php', '_self');
                   } else {

                    }



                }
            }
        }
    } catch (error) {
        console.log(error);
    }

}

async function getAllSellerItemDisplay() {
    try {
            let response = await getAllItemRecords();
            if (response.status === 200) {
                
                let records = await response.json();
                let numberOfRecords = records.count;
                
                
            
            //alert(response.status);
       
            //alert(records.data[0].picdata);
            //alert(records.data[0].name);
            
            sellername = localStorage.getItem("SellerUsername");
            //alert(sellername);
            no_list = 0;
            for (i = 0; i < numberOfRecords; i++){
                if (records.data[i].username===sellername){
                    no_list++;
                }
            }
            
            no_sold = 0;
            for (i = 0; i < numberOfRecords; i++){
                if (records.data[i].username===sellername && records.data[i].sold === 1 ){
                    no_sold++;
                }
            }
            localStorage.setItem('sold',no_sold);
            
            
            
            if(no_sold > 10){
                
                var iconContainer = document.getElementById("verification");
                iconContainer.innerHTML = '<i class="fa fa-check verified-icon"></i>';
                
            }
            
            document.getElementById("numberOfsold").innerHTML = no_sold;
            document.getElementById("numberOflistings").innerHTML = no_list;
            
            
          
            
            
           
            //alert(records.data[2].price)

            if (numberOfRecords > 0) {
                for (i = 0; i < numberOfRecords; i++) {
                    //return records.data[i]; 


                    if (records.data[i].username===sellername) {
                        //alert(i);
                        //alert(records.data[i].picdata);
                        if (records.data[i].sold === 0){
                            let cardContainer = document.createElement("div");
                            cardContainer.classList.add("col-lg-4");
                            cardContainer.addEventListener("click", (function (i) {
                                return function () {
                                    //alert(i);

                                    window.location.href = "myItemDetails.php?itemId=" + i;
                                };
                            })(i));


                            let card = document.createElement("div");
                            card.classList.add("card", "shadow-sm");


                            let username = records.data[i].username;

                            let trainerItem = document.createElement("div");
                            trainerItem.classList.add("trainer-item");


                            let imageThumb = document.createElement("div");
                            imageThumb.classList.add("image-thumb");

                            let image = document.createElement("img");
                            image.src = 'data:image/jpeg;base64,' + records.data[i].picdata;
                            image.style.width = "320px";
                            image.style.height = "300px";
                            image.alt = records.data[i].name;
                            imageThumb.appendChild(image);
                            trainerItem.appendChild(imageThumb);

                            let downContent = document.createElement("div");
                            downContent.classList.add("down-content");

                            let price = document.createElement("span");
                            price.innerHTML = "$" + records.data[i].price;

                            let title = document.createElement("h4");
                            title.innerHTML = records.data[i].name;

                            let description = document.createElement("p");
                            description.innerHTML = records.data[i].description;
                            downContent.appendChild(price);
                            downContent.appendChild(title);

                            let socialIcons = document.createElement("ul");
                            socialIcons.classList.add("social-icons");

                            let likeBtn = document.createElement("li");

                           
                            socialIcons.appendChild(likeBtn);
                            downContent.appendChild(socialIcons);
                            trainerItem.appendChild(downContent);
                            cardContainer.appendChild(trainerItem);

                            targetDiv = document.querySelector("#myitems").appendChild(cardContainer);
                        }else{
                            
                            let cardContainer = document.createElement("div");
                            cardContainer.classList.add("col-lg-4");
                            let card = document.createElement("div");
                            card.classList.add("card", "shadow-sm");

                            let username = records.data[i].username;

                            let trainerItem = document.createElement("div");
                            if (records.data[i].sold === 1) {
                               trainerItem.classList.add("sold");
                                let soldMessage = document.createElement("p");
                                soldMessage.innerHTML = "SOLD";
                                soldMessage.style.color = "red";
                                soldMessage.style.position = "absolute";
                                soldMessage.style.top = "50%";
                                soldMessage.style.left = "50%";
                                soldMessage.style.transform = "translate(-50%, -50%)";
                                soldMessage.style.fontWeight = "bold";
                                soldMessage.style.zIndex = "1";
                                trainerItem.appendChild(soldMessage);
                                trainerItem.classList.add("trainer-item");

                                let imageThumb = document.createElement("div");
                                imageThumb.classList.add("image-thumb");

                                let image = document.createElement("img");
                                image.src = 'data:image/jpeg;base64,' + records.data[i].picdata;
                               image.style.width = "300px";
                                image.style.height = "300px";
                                image.alt = records.data[i].name;
                                imageThumb.appendChild(image);
                                trainerItem.appendChild(imageThumb);

                                let downContent = document.createElement("div");
                                downContent.classList.add("down-content");

                                let price = document.createElement("span");
                                price.innerHTML = "$" + records.data[i].price;

                                let title = document.createElement("h4");
                                title.innerHTML = records.data[i].name;

                                let description = document.createElement("p");
                                description.innerHTML = records.data[i].description;
                                downContent.appendChild(price);
                                downContent.appendChild(title);

                                let socialIcons = document.createElement("ul");
                                socialIcons.classList.add("social-icons");

                                let likeBtn = document.createElement("li");

                                
                                //socialIcons.appendChild(likeBtn);
                                downContent.appendChild(socialIcons);
                                trainerItem.appendChild(downContent);
                                cardContainer.appendChild(trainerItem);

                                targetDiv = document.querySelector("#myitems").appendChild(cardContainer);
                            }
                            

                        }
                    
                    }


                    username = checkUserName();
                    if (username === null) {
                        alert('Please login first!');
                        window.open('loginPage.php', '_self');
                   } else {

                    }



                }
            }
        }
    } catch (error) {
        console.log(error);
    }

}





function reviewResetError() {
    document.getElementById("errcatch").innerHTML = "";
}

//Get All Review Record
async function getAllReviewRecords(){
    const options = {
        method: "get",
        headers: myHeaders
    };
    try{
        let response = await fetch(reviewUrl+"rows", options);
        //alert(response.status);
        return response;
    }catch(error){
        console.log(error);
    }
}



//Validate Review Page details
function validateReviewPage() {
    reviewResetError();
    let error = false;
    
    let review = document.getElementById("review").value.trim();
    
    if (!review) {
        document.getElementById("errcatch").innerHTML = "Please Enter A Description!";
        error = true;
    }
    
    return error;
}

//Display latest inserted review
//async function DisplayLatestReview(){
    //try {
        //let response = await getAllReviewRecords();
        //alert(response.status);
        //if (response.status === 200) {
            //records = await response.json();
            //let numberOfRecords = records.count;
            //alert(records.data[0].review);
            //i = numberOfRecords-1;

            //let container = document.createElement("div");
            //container.className = "review-container";

            //let username = document.createElement("p");
            //username.id = "uname";
            //username.innerHTML = records.data[i].username;
            //container.appendChild(username);

            //let displayRev = document.createElement("p");
            //displayRev.id = "displayrev";
            //displayRev.innerHTML = records.data[i].review;
            //container.appendChild(displayRev);

            //let parent = document.getElementById("reviews-container");
            //parent.appendChild(container);


            //username = checkUserName();
            //if (username === null) {
               // alert('Please login first!');
                //window.open('loginPage.php', '_self');
            //} else {

            //}





       // }
    //} catch (error) {
        //console.log(error);
    //}
//}

let numberOfselectedStars = 0;
//Select stars for Review
async function starSelection() {
  const stars = Array.from(document.querySelectorAll('.fa-star'));
  //let numberOfselectedStars = 0;

  return new Promise(resolve => {
    for (let star of stars) {
      star.addEventListener('click', function() {
        for (let s of stars) {
          s.classList.remove('checked');
        }
        for (let i = 0; i < stars.indexOf(star) + 1; i++) {
          stars[i].classList.add('checked');
          numberOfselectedStars = i + 1;
        }
        resolve(numberOfselectedStars);
      });
    }
  });
}


function RevieweraseText() {
    document.getElementById("review").value = "";
}


async function getNumberOfUserRecords() {
    try {
        let response = await getAllUserRecords();
        if (response.status === 200) {
            let records = await response.json();
            return records.count;
        } else {
            throw new Error(`Failed to get user records, status code: ${response.status}`);
        }
    } catch (error) {
        throw error;
    }
}


//Insert Review Record
async function insertReview() {
    if (validateReviewPage()) {
        return;
    }

    
    seller = localStorage.getItem("SellerUsername");
    
    
    current_user = checkUserName();
    if (!current_user) {
        alert("Please login first!");
        window.open("loginPage.php", "_self");
        return;
    }

    let allData = await getAllReviewRecords();
    
    let lastID = 0;
    if (allData.status === 200) {
        let rec = await allData.json();
        lastID = rec.count;
    }
    lastID += 1;
    
    
    let rating = numberOfselectedStars;
    seller = localStorage.getItem("SellerUsername");
    buyer = checkUserName();
    
    let review = document.getElementById("review").value;
    
    if (numberOfselectedStars >0){
        let updatedata = JSON.stringify({id: lastID, rating, review, seller,buyer});
        const options = {
            method: "post",
            headers: myHeaders,
            body: updatedata
        };

        fetch(reviewUrl, options)
                .then((response) => {
                    if (response.status === 201) {
                        alert("Review uploaded Successfully");


                    } else {
                        alert("Upload failed");
                    }
                })
                .catch((error) => {
                    console.error(error);
                    //alert("Failed to insert Record");
                });
        //DisplayLatestReview();
            
        RevieweraseText();
            
    }else{
        document.getElementById("errstar").innerHTML = "Please Select at least One Star!";
        RevieweraseText();
    }
 
    
    
}

async function overallRating(){
 try {
        let response = await getAllReviewRecords();
        if (response.status === 200) {
            records = await response.json();
            let numberOfRecords = records.count;
            total_ratings = 0;
            no_user_rev = 0;
            
            for (i = 0; i < numberOfRecords; i++) {
                if(records.data[i].buyer === checkUserName()){
                    total_ratings += records.data[i].rating;
                    no_user_rev ++;
                }
            }
            average_ratings = total_ratings/no_user_rev;
            let rounded_average = Math.round(average_ratings);
            let starContainer = document.createElement("div");
                    
            for (let j = 0; j < rounded_average; j++) {
                let star = document.createElement("span");
                star.className = "fa fa-star yellow-star";
                starContainer.appendChild(star);
            }
            document.getElementById("average_rating").appendChild(starContainer);
        }
    } catch (error) {
        console.log(error);
    }
}


async function overallSellerRating(){
 try {
        let response = await getAllReviewRecords();
        if (response.status === 200) {
            records = await response.json();
            let numberOfRecords = records.count;
            total_ratings = 0;
            no_user_rev = 0;
            let seller = localStorage.getItem("SellerUsername");
            for (i = 0; i < numberOfRecords; i++) {
                if(records.data[i].seller === seller){
                    total_ratings += records.data[i].rating;
                    no_user_rev ++;
                }
            }
            average_ratings = total_ratings/no_user_rev;
            let rounded_average = Math.round(average_ratings);
            let starContainer = document.createElement("div");
                    
            for (let j = 0; j < rounded_average; j++) {
                let star = document.createElement("span");
                star.className = "fa fa-star yellow-star";
                starContainer.appendChild(star);
            }
            document.getElementById("average_rating").appendChild(starContainer);
        }
    } catch (error) {
        console.log(error);
    }
}



async function getAllReviewDisplay() {
    try {
        let response = await getAllReviewRecords();
        //alert(response.status);
        if (response.status === 200) {
            records = await response.json();
            let numberOfRecords = records.count;
            //alert(records.data[1].review);
            //alert(numberOfRecords);
            
            
            
           if (numberOfRecords > 0) {
                for (i = 0; i < numberOfRecords; i++) {
                  //alert(records.data[i].username);
                  //alert(records.data[i].username);
                   if (records.data[i].seller === checkUserName()) {
                  
                    let container = document.createElement("div");
                    container.className = "review-container";

                    let username = document.createElement("div");
                    username.id = "uname";
                    username.innerHTML = records.data[i].buyer;
                    container.appendChild(username);
                    
                    let starContainer = document.createElement("div");
                    
                    for (let j = 0; j < records.data[i].rating; j++) {
                        let star = document.createElement("span");
                        star.className = "fa fa-star yellow-star";
                        starContainer.appendChild(star);
                    }
                    
                    
                    container.appendChild(starContainer);

                    let displayRev = document.createElement("p");
                    displayRev.id = "displayrev";
                    displayRev.innerHTML = records.data[i].review;
                    container.appendChild(displayRev);
                    
                    let parent = document.getElementById("reviews-container");
                    parent.appendChild(container);


                    username = checkUserName();
                    if (username === null) {
                        alert('Please login first!');
                        window.open('loginPage.php', '_self');
                    } else {

                    }
                }



                }
            
            }
        }
    } catch (error) {
        console.log(error);
    }

}

async function getAllSellerReviewDisplay() {
    try {
        let response = await getAllReviewRecords();
        //alert(response.status);
        if (response.status === 200) {
            records = await response.json();
            let numberOfRecords = records.count;
            //alert(records.data[1].review);
            //alert(numberOfRecords);
            
            
           let sellername = localStorage.getItem("SellerUsername");
           if (numberOfRecords > 0) {
                for (i = 0; i < numberOfRecords; i++) {
                  //alert(records.data[i].username);
                  //alert(records.data[i].username);
                   if (records.data[i].seller === sellername) {
                  
                    let container = document.createElement("div");
                    container.className = "review-container";

                    let username = document.createElement("div");
                    username.id = "uname";
                    username.innerHTML = records.data[i].buyer;
                    container.appendChild(username);
                    
                    let starContainer = document.createElement("div");
                    
                    for (let j = 0; j < records.data[i].rating; j++) {
                        let star = document.createElement("span");
                        star.className = "fa fa-star yellow-star";
                        starContainer.appendChild(star);
                    }
                    
                    
                    container.appendChild(starContainer);

                    let displayRev = document.createElement("p");
                    displayRev.id = "displayrev";
                    displayRev.innerHTML = records.data[i].review;
                    container.appendChild(displayRev);
                    
                    let parent = document.getElementById("reviews-container");
                    parent.appendChild(container);


                    username = checkUserName();
                    if (username === null) {
                        alert('Please login first!');
                        window.open('loginPage.php', '_self');
                    } else {

                    }
                }



                }
            
            }
        }
    } catch (error) {
        console.log(error);
    }

}





//Get All User Description Record
async function getAllUserRecords(){
    const options = {
        method: "get",
        headers: myHeaders
    };
    try{
        let response = await fetch(settingUrl+"rows", options);
        //alert(response.status);
        return response;
    }catch(error){
        console.log(error);
    }
}


function settingResetError() {
    document.getElementById("errbio").innerHTML = "";
    
}

//Validate user settings
function validateUsersettings() {
    settingResetError();
    let error = false;
    
    let bio = document.getElementById("bio").value.trim();
    
    
    if (!bio) {
        document.getElementById("errbio").innerHTML = "Please Enter A Description!";
        error = true;
    }
    
    return error;
    
}

function SettingseraseText() {
    document.getElementById("bio").value = "";
    
}

//Insert User Record
async function insertChanges() {
    if (validateUsersettings()) {
        return;
    }

    let username = checkUserName();


    if (!username) {
        alert("Please login first!");
        window.open("loginPage.php", "_self");
        return;
    }

    let allData = await getAllUserRecords();

    let lastID = 0;
    if (allData.status === 200) {
        let rec = await allData.json();
        lastID = rec.count;
    }
    lastID += 1;


    
    let bio = document.getElementById("bio").value;
    //alert(bio);
    

    let updatedata = JSON.stringify({username: username,description: bio});
    

    
    const options = {
        method: "post",
        headers: myHeaders,
        body: updatedata
    };

     fetch(settingUrl, options)
            .then((response) => {
                if (response.status === 201) {
                    //alert("Insert Successfully");
            
                    
                    localStorage.setItem('description',bio);
                    
                   
                    let bioDisplay = document.getElementById("description");
                    if (bioDisplay) {
                        bioDisplay.innerHTML = bio;
                    }


                } else {
                    alert("Failed to upload image");
                }
            })
            .catch((error) => {
                console.error(error);
                //alert("Failed to insert Record");
            });
    //DisplayLatestReview();

    SettingseraseText();


            
}

