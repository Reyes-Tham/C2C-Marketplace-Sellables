<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Sellables</title>
        
        <script>
            var username = localStorage.getItem('username');
        </script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
        <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

        <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">

        <link rel="stylesheet" href="assets/css/style.css">
        <script src="TestFetch.js"></script>
        <script type="text/javascript"
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA9qWyVYGtZqaVlnXQdIDsh_MkIBbL0OfA"></script>
        <script src="https://unpkg.com/location-picker/dist/location-picker.min.js"></script>
        <script>
            function detectMeetUp(){
                dealMethod = document.getElementById("meetUp").checked;
                
                if(dealMethod === true){
                    document.getElementById("map").style.height = "480px";
                    var map = document.getElementById('map');
                    var lp = new locationPicker(map, {
                    setCurrentPosition: true,
                    lat: 1.3521,
                    lng: 103.8198
                    }, {
                    zoom: 12
                    });
                    
                    google.maps.event.addListener(lp.map, 'idle', function (event) {
                        var location = lp.getMarkerPosition();
                        document.getElementById("Lat").innerHTML = location.lat;
                        document.getElementById("Lon").innerHTML = location.lng;
                    });
                }else{
                    document.getElementById("map").style.height = "0px";
                }
            }
        </script>
        
        <style type="text/css">
            #map {
                width: 600px;
                height: 0px;
            }
            
            .error{
                color: white;
            }
            .col-sm-8 col-xs-12{
                color:black;
            }
        </style>
    </head>
    <body>
        
            <!-- ***** Nav Bar Start ***** -->
    <header class="header-area header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                        <!-- ***** Logo Start ***** -->
                        <a href="homepage.php" class="logo" ><em>Sellables</em></a>
                        <!-- ***** Logo End ***** -->
                        <!-- ***** Menu Start ***** -->
                        <ul class="nav">
                            <li><a href="homepage.php" style=" color: black;">Home</a></li>
                            <li class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" style=" color: black;">Categories</a>

                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="allcategorypage.php">All Products</a>
                                    <a class="dropdown-item" href="fashioncategorypage.php">Fashion</a>
                                    <a class="dropdown-item" href="electronicscategorypage.php">Electronics</a>
                                    <a class="dropdown-item" href="fdcategorypage.php">Food & Drinks</a>
                                    <a class="dropdown-item" href="sportscategorypage.php">Sports</a>
                                    <a class="dropdown-item" href="othercategorypage.php">Others</a>
                                </div>
                            </li>
                            <li><a href="chatspage.php" style=" color: black;">Chats</a></li>
                            <li class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" style=" color: black;">Profile</a>

                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="ProfilePage.php">Your Profile</a>
                                    <a class="dropdown-item" href="profilesettingpage.php">Settings</a>
                                </div>
                            </li>
                            <li><a href="aboutpage.php" style=" color: black;">About Us</a></li>
                            <li><a href="newPage.php" style=" color: black;">$ell</a></li>
                            <li><a href="likedpage.php" style=" color: black;" class="heart active">❤️</a></li>
                            <li><a id="navuser" style=" color: black;"><script>let navuser = document.getElementById("navuser");
    navuser.innerHTML = "Welcome Back " + checkUserName();</script></a></li>
                        </ul>        
                        <a class='menu-trigger'>
                            <span>Menu</span>
                        </a>

                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <!-- ***** Nav Bar End ***** -->
        
    <br><br><br><br>
    
        <div class="container">
            <div class="row" style="background-color:#ff5757;border-radius: 2%;">
                <div class="col-md-4"><input type="file" accept="image/jpeg, image/png" id="myFile" name="filename" onchange="loadFile(event)" style="display: none;" >
                    <p><label for="myFile" style="cursor: pointer;color:black">Upload Image</label> <span class="error" id="errImage"></span></p>
                    <img id="output" width="200" /></div>
                <div class="col-md-8">
                    <div class="col-sm-6 col-xs-12"> 
                        <div class="row">		
                            <div class="col-sm-12 col-xs-12">
                                Item Name: <span class="error" id="errItemName"></span><br>
                                <input type="text" name="itemName" id="itemName"/>
                            </div>
                            <div class="col-sm-12 col-xs-12">
                                <br>
                                Category: <span class="error" id="errCategory"></span><br/>
                                <select name="category" id="category">
                                    <option value="select" id="select">--Select Option--</option>
                                    <option value="Fashion" id="Fashion">Fashion</option>
                                    <option value="Electronics" id="Electronics">Electronics</option>
                                    <option value="FoodDrinks" id="FoodDrinks">Food and Drinks</option>
                                    <option value="Sports" id="Sports">Sports</option>
                                    <option value="Others" id="Others">Others</option>
                                </select>      
                            </div>
                            <div class="col-sm-12 col-xs-12">
                                <br>
                                Cost: <span class="error" id="errCost"></span><br>
                                $<input type="number" name="cost" id="cost"/>
                            </div>
                            <div class="col-sm-12 col-xs-12">
                                <br>
                                Condition: <span class="error" id="errCondition"></span><br>
                                New: <input type="radio" name="condition" value="New" id="new"/>
                                Used: <input type="radio" name="condition" value="Used" id="used"/>
                                Old: <input type="radio" name="condition" value="Old" id="old"/>
                            </div>
                            <div class="col-sm-12 col-xs-12">
                                <br>
                                Description (Max 500 Words): <span class="error" id="errDesc"></span><br>
                                <textarea id="description" name="description" rows="5" cols="80" maxlength="500" placeholder="Describe your item here! What is it, What does it do?"></textarea>
                            </div>
                            <div class="col-sm-12 col-xs-12">
                                <br>
                                Dealing Method: <span class="error" id="errMethod"></span><br>
                                <input type="checkbox" name="dealMethod" value="meetUp" id="meetUp" onclick="detectMeetUp()"/>Meet-Up
                                <input type="checkbox" name="dealMethod" value="delivery" id="delivery"/>Delivery
                            </div>
                            <div class="col-auto">
                                <div id="map"></div>
                                <p><br>Lat: <span id="Lat">0</span> , Lon: <span id="Lon">0</span>
                            </div>
                            <div class="col-sm-12 col-xs-12">
                                <br>
                                <input type="button" value="Create Listing" onclick="insertItem(ImageURL)"/>
                                <br>
                                <br>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </script>
        <img id="output" width="200" />	
        <script>
            var ImageURL="0";
            var loadFile = function(event) {
            //var image = document.getElementById('output');
            ImageURL = URL.createObjectURL(event.target.files[0]);
            displayImageFromUrl(URL.createObjectURL(event.target.files[0]),'output');
            //insertImage(URL.createObjectURL(event.target.files[0]));
            //image.src = URL.createObjectURL(event.target.files[0]);
            //alert(URL.createObjectURL(event.target.files[0]));
        };
        </script>

    </div>
    
        <!-- Footer Starts Here -->
    <footer
        class="text-center text-lg-start text-white"
        style="background-color: #555555"
        >
        <!-- Grid container -->
        <div class="container p-4 pb-0">
            <!-- Section: Links -->
            <section class="">
                <!--Grid row-->
                <div class="row">
                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold" style=' color: #ff5757'>
                            Sellables
                        </h6>
                        <p style=" color: white;">
                            Sellables is a website to make the buying and selling of items between users more easy and accessible. Sellable aims to be a safe, easy to use and platform for buyers and sellers alike.
                        </p>
                    </div>
                    <!-- Grid column -->

                    <hr class="w-100 clearfix d-md-none" />

                    <!-- Grid column -->
                    <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold">Categories</h6>
                        <p>
                            <a class="text-white" href="allcategorypage.php">All Products</a>
                        </p>
                        <p>
                            <a class="text-white" href='fashioncategorypage.php'>Fashion</a>
                        </p>
                        <p>
                            <a class="text-white" href="electronicscategorypage.php">Electronics</a>
                        </p>
                        <p>
                            <a class="text-white" href="fdcategorypage.php">Food & Drinks</a>
                        </p>
                        <p>
                            <a class="text-white" href="sportscategorypage.php">Sports</a>
                        </p>
                        <p>
                            <a class="text-white" href='othercategorypage.php'>Others</a>
                        </p>
                    </div>
                    <!-- Grid column -->

                    <hr class="w-100 clearfix d-md-none" />

                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold">
                            Useful Links
                        </h6>
                        <p>
                            <a class="text-white" href='newPage.php'>Sell</a>
                        </p>
                        <p>
                            <a class="text-white" href="chatspage.php">Chats</a>
                        </p>
                        <p>
                            <a class="text-white" href="ProfilePage.php">Your Profile</a>
                        </p>
                        <p>
                            <a class="text-white" href='likedpage.php'>Your Likes</a>
                        </p>
                        <p>
                            <a class="text-white" href="aboutpage.php">About Us</a>
                        </p>
                    </div>

                    <!-- Grid column -->
                    <hr class="w-100 clearfix d-md-none" />

                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold">Contact Us</h6>
                        <div class="col-md-5 col-lg-4 ml-lg-0 text-center text-md-end">
                        <!-- Facebook -->
                        <a
                            class="btn btn-outline-light btn-floating m-1"
                            class="text-white"
                            role="button"
                            style=' height: 60px; width:150px;'
                            href='https://www.facebook.com/'
                            ><i class="fab fa-facebook-f"></i
                            > <div>Facebook</div></a> 

                        <!-- Twitter -->
                        <a
                            class="btn btn-outline-light btn-floating m-1"
                            class="text-white"
                            role="button"
                            style=' height: 60px; width:150px;'
                            href='https://twitter.com/'
                            ><i class="fab fa-twitter"></i
                            ><div>Twitter</div></a>

                        <!-- Instagram -->
                        <a
                            class="btn btn-outline-light btn-floating m-1"
                            class="text-white"
                            role="button"
                            style=' height: 60px; width:150px;'
                            href='https://www.instagram.com/'
                            ><i class="fab fa-instagram"></i
                            ><div>Instagram</div></a>
                    </div>
                    </div>
                    <!-- Grid column -->
                </div>
                <!--Grid row-->
            </section>
            <!-- Section: Links -->

            
        </div>
        <!-- Grid container -->
    </footer>
    
    <!-- Footer Ends Here -->
    
     <!-- jQuery -->
    <script src="assets/js/jquery-2.1.0.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Plugins -->
    <script src="assets/js/scrollreveal.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/imgfix.min.js"></script> 
    <script src="assets/js/mixitup.js"></script> 
    <script src="assets/js/accordions.js"></script>
    
    <!-- Global Init -->
    <script src="assets/js/custom.js"></script>
    
    </body>
</html>
