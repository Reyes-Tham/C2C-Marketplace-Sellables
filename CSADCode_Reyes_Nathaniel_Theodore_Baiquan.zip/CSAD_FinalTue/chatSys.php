<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
        <style>
            #messages-container {
                height: 850px;
                overflow-y: scroll;
            }
            #send-button {
                position: fixed;
                bottom: 0;
                left: 0;
            }
            .error {
                color: red;
            }
            .sender {
                color: blue;
            }

            .receiver {
                color: darkred;
            }
        </style>
       <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

        <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">

        <link rel="stylesheet" href="assets/css/style.css">
        <script src="TestFetch.js"></script>
    </head>
    <body onload="loadMessages()" style="background-image: url(assets/images/background.jpg)">
        <script>
            setInterval(loadMessages, 500);
        </script>
        <h1 id="user2">Chat System</h1>
        <h3>Item: <span id="title"></span></h3>
        <div id="messages-container">
            <table id="messages">
            </table>
        </div>
        <div id="send-button">
            <input type="text" id="message" placeholder="type message here..." size="70"/>
            <input type="button" value="Send"  size="34%" onclick="insertMessage()" />
            <br>
            <span class="error" id="errMessage"></span>
        </div>
    </body>
</html>

