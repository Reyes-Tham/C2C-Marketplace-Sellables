<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

    <title>Sellables</title>
    <script src="TestFetch.js"></script>
    
    
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">

    <link rel="stylesheet" href="assets/css/style.css">
        
    <script>
        var sellername = localStorage.getItem("SellerUsername");
        
    </script>
    <style>
            
       .red-heart {
          color: red;
      }
      #profile-pic {
            border-radius: 50%;
            width: 200px;
            height: 200px;
        }
        .verified-icon {
            display: inline-block;
            width: 20px;
            height: 20px;
            background-color: red;
            border-radius: 50%;
            text-align: center;
        }

        .verified-icon {
            color: white;
            font-size: 16px;
            line-height: 20px;
        }
        .yellow-star {
          color: orange;
      }
      #profile_uname{
          font-weight: bold;
          text-align: center;
          font-size: 20px;
      }
      #left-sidebar {
          width: 300px;
          height: 500px;
          float: left;
          margin-left: 50px;
      }
      #right-sidebar {
          margin-left: 200px;
      }
      #profile-column {
        width: 300px;
        height: 500px;
        float: left;
        margin-left: 50px;
        position: absolute;
        top: 60%;
        left: 1.7%;
        
        }



    </style>

    </head>
    
    <body onload="getAllSellerItemDisplay();overallSellerRating();DisplaySellerVerification();">
    
    <!-- ***** Preloader Start ***** -->
    <div id="js-preloader" class="js-preloader">
      <div class="preloader-inner">
        <span class="dot"></span>
        <div class="dots">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
    </div>
    <!-- ***** Preloader End ***** -->
    
    
    <header class="header-area header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                        <!-- ***** Logo Start ***** -->
                        <a href="homepage.php" class="logo" ><em>Sellables</em></a>
                        <!-- ***** Logo End ***** -->
                        <!-- ***** Menu Start ***** -->
                        <ul class="nav">
                            <li><a href="homepage.php" style=" color: black;">Home</a></li>
                            <li class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" style=" color: black;">Categories</a>

                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="allcategorypage.php">All Products</a>
                                    <a class="dropdown-item" href="fashioncategorypage.php">Fashion</a>
                                    <a class="dropdown-item" href="electronicscategorypage.php">Electronics</a>
                                    <a class="dropdown-item" href="fdcategorypage.php">Food & Drinks</a>
                                    <a class="dropdown-item" href="sportscategorypage.php">Sports</a>
                                    <a class="dropdown-item" href="othercategorypage.php">Others</a>
                                </div>
                            </li>
                            <li><a href="chatspage.php" style=" color: black;">Chats</a></li>
                            <li class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" style=" color: black;">Profile</a>

                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="ProfilePage.php">Your Profile</a>
                                    <a class="dropdown-item" href="profilesettingpage.php">Settings</a>
                                </div>
                            </li>
                            <li><a href="aboutpage.php" style=" color: black;">About Us</a></li>
                            <li><a href="newPage.php" style=" color: black;">$ell</a></li>
                            <li><a href="likedpage.php" style=" color: black;" class="heart active">❤️</a></li>
                            <li><a id="navuser" style=" color: black;"><script>let navuser = document.getElementById("navuser");
    navuser.innerHTML = "Welcome Back " + checkUserName();</script></a></li>
                        </ul>        
                        <a class='menu-trigger'>
                            <span>Menu</span>
                        </a>

                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <!-- ***** Nav Bar End ***** -->

    <section class="section section-bg" id="call-to-action" >
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="cta-content">
                        <br>
                        <br>
                        <h2>Profile</em></h2>
                        
                        
                    </div>
                </div>
            </div>
        </div>
    </section>
    
    
    <!-- Sidebar/menu -->
        
          
    <div id="left-sidebar">  
            
           
            <div><br>
                    
                        <img id="profile-pic"/>
                        <script>
                            displayProfileImageInProffile(sellername);
                        </script>
                        
                    </div>
            
                <br><br>
                <div id ="profile-column">
                    <br><br><br><br><br><br>
                <div style="display: flex; flex-direction: row;">   
     
                    <p id="profile_uname"></p> 
                    <span style="margin-left: 5px;" id="verification" ></span>
                    <script>
                    //async function displayUsername() {
                    //let usernameId;
                    //let numberOfRecords = await getNumberOfUserRecords();
                    //if (numberOfRecords === 0) {
                        // = localStorage.getItem('username');
                    //} else if (numberOfRecords > 0) {
                       //usernameId = await getLatestUsername();
                    //}
                    //let usernameDisplay = document.getElementById("profile_uname");
                    //if (usernameDisplay) {
                        //usernameDisplay.innerHTML = usernameId;
                        //}
                    //}
                    

                    //displayUsername();
                    //alert(localStorage.getItem('username'));
                    var sellername = localStorage.getItem("SellerUsername");
                    document.getElementById("profile_uname").innerHTML = sellername;
                    </script>
                    
                
                </div>
                <div id ="average_rating">
                    
                </div>
                <br>
                <div style="display: flex; flex-direction: row;">
                    <span>Sold Items:</span>
                    <span id = "numberOfsold" style="margin-left: 5px;"></span>
                    <script>
                        document.getElementById("numberOfsold").innerHTML = localStorage.getItem('sold');
                    </script>
                </div>
               

                About Me:<br>
                <p id="description">Description</p>
                <script>
                    //async function setLatestDescription() {
                        //try {
                        // latestDescription = await getLatestDesc();
                        //document.getElementById("description").innerHTML = latestDescription;
                        //} catch (error) {
                            //console.log(error);
                        //}
                    //}
                    //setLatestDescription();
                    var description = localStorage.getItem('description');
                    document.getElementById("description").innerHTML =description ;
                </script>
                </div>
                </div>
                
                
   

    <div class="w3-main" id="right-sidebar" >
        <br>
  
        <span class="w3-button w3-hide-large w3-xxlarge w3-hover-text-grey" onclick="w3_open()"><i class="fa fa-bars"></i></span>
        <button class="w3-button w3-black" >Listings</button>
        <a class="w3-button w3-white" href="SellerReviewPage.php">Reviews</a>
        
        
        


                
        <section class="section" id="trainers">
            <br>
            <div style="display: flex; flex-direction: row;">
            <h2 id = "numberOflistings"></h2>
            <h2 style="margin-left: 10px;">Listing(s)</h2>
            </div>
        <div class="container" id="card">
            <div class="row">
                <br>
                <div class="col-lg-6 offset-lg-3">
                    
                </div>
            </div>
                <div class="row" id="myitems">
                
                </div>

            <br>

            
        </div>
        </section>


       
    </div>  
    
    
    <!-- Footer Starts Here -->
    <footer
        class="text-center text-lg-start text-white"
        style="background-color: #555555"
        >
        <!-- Grid container -->
        <div class="container p-4 pb-0">
            <!-- Section: Links -->
            <section class="">
                <!--Grid row-->
                <div class="row">
                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold" style=' color: #ff5757'>
                            Sellables
                        </h6>
                        <p style=" color: white;">
                            Sellables is a website to make the buying and selling of items between users more easy and accessible. Sellable aims to be a safe, easy to use and platform for buyers and sellers alike.
                        </p>
                    </div>
                    <!-- Grid column -->

                    <hr class="w-100 clearfix d-md-none" />

                    <!-- Grid column -->
                    <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold">Categories</h6>
                        <p>
                            <a class="text-white" href="allcategorypage.php">All Products</a>
                        </p>
                        <p>
                            <a class="text-white" href='fashioncategorypage.php'>Fashion</a>
                        </p>
                        <p>
                            <a class="text-white" href="electronicscategorypage.php">Electronics</a>
                        </p>
                        <p>
                            <a class="text-white" href="fdcategorypage.php">Food & Drinks</a>
                        </p>
                        <p>
                            <a class="text-white" href="sportscategorypage.php">Sports</a>
                        </p>
                        <p>
                            <a class="text-white" href='othercategorypage.php'>Others</a>
                        </p>
                    </div>
                    <!-- Grid column -->

                    <hr class="w-100 clearfix d-md-none" />

                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold">
                            Useful Links
                        </h6>
                        <p>
                            <a class="text-white" href='newPage.php'>Sell</a>
                        </p>
                        <p>
                            <a class="text-white" href="chatspage.php">Chats</a>
                        </p>
                        <p>
                            <a class="text-white" href="ProfilePage.php">Your Profile</a>
                        </p>
                        <p>
                            <a class="text-white" href='likedpage.php'>Your Likes</a>
                        </p>
                        <p>
                            <a class="text-white" href="aboutpage.php">About Us</a>
                        </p>
                    </div>

                    <!-- Grid column -->
                    <hr class="w-100 clearfix d-md-none" />

                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold">Contact Us</h6>
                        <div class="col-md-5 col-lg-4 ml-lg-0 text-center text-md-end">
                        <!-- Facebook -->
                        <a
                            class="btn btn-outline-light btn-floating m-1"
                            class="text-white"
                            role="button"
                            style=' height: 60px; width:150px;'
                            href='https://www.facebook.com/'
                            ><i class="fab fa-facebook-f"></i
                            > <div>Facebook</div></a> 

                        <!-- Twitter -->
                        <a
                            class="btn btn-outline-light btn-floating m-1"
                            class="text-white"
                            role="button"
                            style=' height: 60px; width:150px;'
                            href='https://twitter.com/'
                            ><i class="fab fa-twitter"></i
                            ><div>Twitter</div></a>

                        <!-- Instagram -->
                        <a
                            class="btn btn-outline-light btn-floating m-1"
                            class="text-white"
                            role="button"
                            style=' height: 60px; width:150px;'
                            href='https://www.instagram.com/'
                            ><i class="fab fa-instagram"></i
                            ><div>Instagram</div></a>
                    </div>
                    </div>
                    <!-- Grid column -->
                </div>
                <!--Grid row-->
            </section>
            <!-- Section: Links -->

            
        </div>
        <!-- Grid container -->
    </footer>
    
    <!-- Footer Ends Here -->
            
    <!-- jQuery -->
    <script src="assets/js/jquery-2.1.0.min.js"></script>
    <!-- Bootstrap -->
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <!-- Plugins -->
    <script src="assets/js/scrollreveal.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/imgfix.min.js"></script> 
    <script src="assets/js/mixitup.js"></script> 
    <script src="assets/js/accordions.js"></script>
    
    <!-- Global Init -->
    <script src="assets/js/custom.js"></script>
  </body>
</html>
