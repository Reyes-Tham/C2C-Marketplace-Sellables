<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">

    <title>Sellables</title>
    <script type="text/javascript"
        src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA9qWyVYGtZqaVlnXQdIDsh_MkIBbL0OfA"></script>
    <script src="https://www.paypal.com/sdk/js?client-id=AWh0gkbsMqEOY3BtEO1TllFYE4itO8kHuP_CJfqEezEvhHL20-87F9CbPCxEh6CuDyhNtVyidlwTBErZ"></script>

    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">

    <link rel="stylesheet" href="assets/css/style.css">
    <style>
       
        
        #imgid{
             width: 200px;
             height: 200px;
        }
    </style>

    </head>
    
    <body>
    
    <!-- ***** Preloader Start ***** -->
    <div id="js-preloader" class="js-preloader">
      <div class="preloader-inner">
        <span class="dot"></span>
        <div class="dots">
          <span></span>
          <span></span>
          <span></span>
        </div>
      </div>
    </div>
    <!-- ***** Preloader End ***** -->
    
    
    <!-- ***** Nav Bar Start ***** -->
    <header class="header-area header-sticky">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <nav class="main-nav">
                        <!-- ***** Logo Start ***** -->
                        <a href="homepage.php" class="logo" ><em>Sellables</em></a>
                        <!-- ***** Logo End ***** -->
                        <!-- ***** Menu Start ***** -->
                        <ul class="nav">
                            <li><a href="homepage.php" style=" color: black;">Home</a></li>
                            <li class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" style=" color: black;">Categories</a>

                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="allcategorypage.php">All Products</a>
                                    <a class="dropdown-item" href="fashioncategorypage.php">Fashion</a>
                                    <a class="dropdown-item" href="electronicscategorypage.php">Electronics</a>
                                    <a class="dropdown-item" href="fdcategorypage.php">Food & Drinks</a>
                                    <a class="dropdown-item" href="sportscategorypage.php">Sports</a>
                                    <a class="dropdown-item" href="othercategorypage.php">Others</a>
                                </div>
                            </li>
                            <li><a href="chatspage.php" style=" color: black;">Chats</a></li>
                            <li class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" style=" color: black;">Profile</a>

                                <div class="dropdown-menu">
                                    <a class="dropdown-item" href="ProfilePage.php">Your Profile</a>
                                    <a class="dropdown-item" href="profilesettingpage.php">Settings</a>
                                </div>
                            </li>
                            <li><a href="aboutpage.php" style=" color: black;" class="active">About Us</a></li>
                            <li><a href="newPage.php" style=" color: black;">$ell</a></li>
                            <li><a href="likedpage.php" style=" color: black;" class="heart active">❤️</a></li>
                            <li><a id="navuser" style=" color: black;"><script>let navuser = document.getElementById("navuser");
    navuser.innerHTML = "Welcome Back " + checkUserName();</script></a></li>
                        </ul>        
                        <a class='menu-trigger'>
                            <span>Menu</span>
                        </a>

                        <!-- ***** Menu End ***** -->
                    </nav>
                </div>
            </div>
        </div>
    </header>

    <!-- ***** Nav Bar End ***** -->

    

    <section class="section section-bg" id="call-to-action" >
        <div class="container">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <div class="cta-content">
                        <br>
                        <br>
                        <h2>About <em> Us</em></h2>
                        
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- ***** Our Classes Start ***** -->
    <section class="section" id="our-classes">
        <div class="container">
            <br>
            <br>
            <br>
            <div class="row" id="tabs">
              <div class="col-lg-4">
                <ul>
                  <li><a href='#tabs-1'> Reyes</a></li>
                  <li><a href='#tabs-2'> Nathaniel</a></a></li>
                  <li><a href='#tabs-3'>Theodore</a></a></li>
                  <li><a href='#tabs-4'>Baiquan</a></a></li>
                  <li><a href='#tabs-5'><i class="fa fa-credit-card"></i> Paypal</a></a></li>
                  <li><a href='#tabs-6'><i class="fa fa-map-marker"></i> Location</a></a></li>
                </ul>
              </div>
              <div class="col-lg-8">
                <section class='tabs-content'>
                  <article id='tabs-1'>
                     <h4>Reyes</h4>
                     <h5>P2124661</h5>
                    
                    <img src="assets/images/reyes.jpg" alt="" id="imgid">
                    <br>
                    <p>Implemented Astradb database, 
                        Login Page,
                        Sell/New Item Page,
                        Chat Page,
                        Paypal(Donation).</p>
                    
                    
                    
                    

           
                  </article>
                  <article id='tabs-2'>
                    
                    <h4>Nathaniel</h4>
                    <h5>P2124463</h5>
                    <img src="assets/images/nathaniel.jpg" alt="" id="imgid">
                    <br>
                    <p>
                        Implemented design of website(nav bar and footer),
                        homepage(with search function),
                        category pages(Buyer Item Details),
                        liked page(with features).
                        
                    </p>
                  </article>
                    <article id='tabs-3'>
                        <h4>Theodore</h4>
                        <h5>P2124546</h5>
                    <img src="assets/images/theodore.JPG" alt="" id="imgid">
                    <br>
                    
                    <p>Theodore: Implemented Profile Page(Review Page/Listing Page),
                        Seller Item Page(Edit/Update Price, Seller Item Details),
                        Profile Settings Page,
                        About Page.
                    </p>
                    

                    <p></p>
                  </article>
                    <article id='tabs-4'>
                        <h4>Baiquan</h4>
                        <h5>P2111632</h5>
                       
                        <img src="assets/images/baiquan.jpg" alt="" id="imgid">
                        
                        <br>
                        <p>
                            Implemented bootstrap/design of website(nav bar and footer)
                        </p>
                    </article>
                    <article id='tabs-5'>
                        <h1>Donate $5 to Sellable</h1>
                        <br>
                        <!-- PayPal button -->
                        <div id="paypal-button-container"></div>
                        <!-- JavaScript code -->
                        
                        <script>
                          paypal.Buttons({
                            createOrder: function(data, actions) {
                              return actions.order.create({
                                purchase_units: [{
                                  amount: {
                                    value: '5'
                                  }
                                }]
                              });
                            },
                            onApprove: function(data, actions) {
                              return actions.order.capture().then(function(details) {
                                // Show success message to the buyer
                                alert('Transaction completed by ' + details.payer.name.given_name + '!');
                              });
                            }
                          }).render('#paypal-button-container');
                        </script>
                    </article>
                    <article id='tabs-6'>
                        <h4>Company Address: 500 Dover Rd, Singapore 139651</h4>
                        <div id="map" style="width:400px;height:400px;"></div>
                        <script>
                          function initMap() {
                            var location = {lat: 1.3098, lng: 103.7775};
                            var map = new google.maps.Map(
                                document.getElementById('map'), {zoom: 15, center: location});
                            var marker = new google.maps.Marker({position: location, map: map});
                          }
                        </script>
                        <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA9qWyVYGtZqaVlnXQdIDsh_MkIBbL0OfA&callback=initMap"
                        async defer></script>
                    </article>
                </section>
              </div>
            </div>
        </div>
    </section>
    <!-- ***** Our Classes End ***** -->

        <!-- Footer Starts Here -->
    <footer
        class="text-center text-lg-start text-white"
        style="background-color: #555555"
        >
        <!-- Grid container -->
        <div class="container p-4 pb-0">
            <!-- Section: Links -->
            <section class="">
                <!--Grid row-->
                <div class="row">
                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-3 col-xl-3 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold" style=' color: #ff5757'>
                            Sellables
                        </h6>
                        <p style=" color: white;">
                            Sellables is a website to make the buying and selling of items between users more easy and accessible. Sellable aims to be a safe, easy to use and platform for buyers and sellers alike.
                        </p>
                    </div>
                    <!-- Grid column -->

                    <hr class="w-100 clearfix d-md-none" />

                    <!-- Grid column -->
                    <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold">Categories</h6>
                        <p>
                            <a class="text-white" href="allcategorypage.php">All Products</a>
                        </p>
                        <p>
                            <a class="text-white" href='fashioncategorypage.php'>Fashion</a>
                        </p>
                        <p>
                            <a class="text-white" href="electronicscategorypage.php">Electronics</a>
                        </p>
                        <p>
                            <a class="text-white" href="fdcategorypage.php">Food & Drinks</a>
                        </p>
                        <p>
                            <a class="text-white" href="sportscategorypage.php">Sports</a>
                        </p>
                        <p>
                            <a class="text-white" href='othercategorypage.php'>Others</a>
                        </p>
                    </div>
                    <!-- Grid column -->

                    <hr class="w-100 clearfix d-md-none" />

                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold">
                            Useful Links
                        </h6>
                        <p>
                            <a class="text-white" href='newPage.php'>Sell</a>
                        </p>
                        <p>
                            <a class="text-white" href="chatspage.php">Chats</a>
                        </p>
                        <p>
                            <a class="text-white" href="ProfilePage.php">Your Profile</a>
                        </p>
                        <p>
                            <a class="text-white" href='likedpage.php'>Your Likes</a>
                        </p>
                        <p>
                            <a class="text-white" href="aboutpage.php">About Us</a>
                        </p>
                    </div>

                    <!-- Grid column -->
                    <hr class="w-100 clearfix d-md-none" />

                    <!-- Grid column -->
                    <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mt-3">
                        <h6 class="text-uppercase mb-4 font-weight-bold">Contact Us</h6>
                        <div class="col-md-5 col-lg-4 ml-lg-0 text-center text-md-end">
                        <!-- Facebook -->
                        <a
                            class="btn btn-outline-light btn-floating m-1"
                            class="text-white"
                            role="button"
                            style=' height: 60px; width:150px;'
                            href='https://www.facebook.com/'
                            ><i class="fab fa-facebook-f"></i
                            > <div>Facebook</div></a> 

                        <!-- Twitter -->
                        <a
                            class="btn btn-outline-light btn-floating m-1"
                            class="text-white"
                            role="button"
                            style=' height: 60px; width:150px;'
                            href='https://twitter.com/'
                            ><i class="fab fa-twitter"></i
                            ><div>Twitter</div></a>

                        <!-- Instagram -->
                        <a
                            class="btn btn-outline-light btn-floating m-1"
                            class="text-white"
                            role="button"
                            style=' height: 60px; width:150px;'
                            href='https://www.instagram.com/'
                            ><i class="fab fa-instagram"></i
                            ><div>Instagram</div></a>
                    </div>
                    </div>
                    <!-- Grid column -->
                </div>
                <!--Grid row-->
            </section>
            <!-- Section: Links -->

            
        </div>
        <!-- Grid container -->
    </footer>
    
    <!-- Footer Ends Here -->

    <!-- jQuery -->
    <script src="assets/js/jquery-2.1.0.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Plugins -->
    <script src="assets/js/scrollreveal.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/imgfix.min.js"></script> 
    <script src="assets/js/mixitup.js"></script> 
    <script src="assets/js/accordions.js"></script>
    
    <!-- Global Init -->
    <script src="assets/js/custom.js"></script>

  </body>
</html>