<!DOCTYPE html>
<!--
Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
Click nbfs://nbhost/SystemFileSystem/Templates/Scripting/EmptyPHPWebPage.php to edit this template
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title>Login to Sellables</title>
        <script src="TestFetch.js"></script>
        <style>
            .error{
                color: red;
            }
        </style>
        <style>

            form {
                border: 3px solid #f1f1f1;
            }
            body,h1,h2,h3,h4,h5 {
                font-family: "Raleway", sans-serif
            }

            input[type=text], input[type=password] {
                width: 100%;
                padding: 12px 20px;
                margin: 8px 0;
                display: inline-block;
                border: 1px solid #ccc;
                box-sizing: border-box;
            }

            button {
                background-color: #04AA6D;
                color: white;
                padding: 14px 20px;
                margin: 8px 0;
                border: none;
                cursor: pointer;
                width: 100%;
            }

            button:hover {
                opacity: 0.8;
            }

            .cancelbtn {
                width: auto;
                padding: 10px 18px;
                background-color: #f44336;
            }

            .imgcontainer {
                text-align: center;
                margin: 24px 0 12px 0;
            }

            img.avatar {
                width: 40%;
                border-radius: 50%;
            }

            .container {
                padding: 16px;
            }

            span.psw {
                float: right;
                padding-top: 16px;
            }

            /* Change styles for span and cancel button on extra small screens */
            @media screen and (max-width: 300px) {
                span.psw {
                    display: block;
                    float: none;
                }
                .cancelbtn {
                    width: 100%;
                }
            }
            
            

            
            #videothing::-webkit-media-controls {
                display: none !important;
            }
            
            .video-container {
                position: absolute;
                top: 0;
                left: 0;
                height: 100%;
                width: 100%;
            }

            .video-container video {
                height: 100%;
                width: 100%;
                object-fit: cover;
            }

            .login-container {
                background-color: ghostwhite;
                border-radius: 1%;
                width: 50%; 
                height: 60%;
                margin: 0 auto;
                padding: 2em;
                text-align: center;
                justify-content: center;
                align-items: center;
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                z-index: 1;
            }
        </style>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
        <link href="https://fonts.googleapis.com/css?family=Poppins:100,100i,200,200i,300,300i,400,400i,500,500i,600,600i,700,700i,800,800i,900,900i&display=swap" rel="stylesheet">
        <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

        <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">

        <link rel="stylesheet" href="assets/css/style.css">
        
        
    </head>
    <body>
        
        <div class="video-container">
            <video autoplay muted loop>
                <source src="assets/images/login.mp4" type="video/mp4">
            </video>
        </div>

        <div class="login-container">
            <h1>Login To Sellables</h1>
            <br>
            <form action="registerPage.php" style="border:none">
                <label>Username:</label>
                <input type="text" id="userName" name="userName"/>
                <br>
                <label>Password:</label>
                <input type="password" id="password" name="password"/>
                <br><br>
                <input type="button" value="Login" onclick="checkCredentials()"/>&nbsp;&nbsp;&nbsp;&nbsp;
                <input type="submit" value="Register">
            </form>
        </div>

        
        <?php
        // put your code here
        ?>
    </body>
</html>
