var lastID = 0;
var selectedID = 0;
//set token
var Cassandra_Token = "AstraCS:seSLgQJNakqamZKmAFILlZEk:416a2c7155bb21ce24ffde30fb2ddf463e4e62482572fe7aa74ba69c58c2cd33";
//region url
var region = "asia-south1";
//database url
var url = region + "/api/rest/v2/keyspaces/Sellables/sellable/";
//http header
var myHeaders = new Headers();
myHeaders.append("Content-Type","application/json");
myHeaders.append("X-Cassandra-Token",Cassandra_Token);
myHeaders.append("Accept","application/json");

//Read all records from the database
async function getAllRecords(){
    const options = {
        method: "get",
        headers: myHeaders
    };
    try{
        let response = await fetch(url + "rows", options);
        return response;
    } catch(error){
        console.log(error);
    }
}

//Create a dropdown list of all the records read from the database
async function renderAllRecords(){
    let response = await getAllRecords();
    if (response.status === 200){
        records = await response.json();
        let numberOfRecords = records.count;
        let html = '<select id="list" onchange="renderRecordById();">';
        html += '<option selected>--Select an option--</option>';
        let i = 0;
        for(i=0;i<numberOfRecords;i++){
            if(lastID<records.data[i].id){
                lastID = records.data[i].id;
            }
            htmlSegment='<option value="'+records.data[i].id+'">'+records.data[i].name+'</option>';            
        }
        html+='</select>';
        document.getElementById('output').innerHTML = html;
        resetAllFields();
    }else{
        document.getElementById('output').innerHTML = "Error Reading Records";
    }
}

//Read a record  uisng the primary key. id
async function getRecordById(id){
    const options = {
        method: "get",
        headers: myHeaders
    };
    try{
        let response = await fetch(url + id, options);
        return response;
    }catch(error){
        console.log(error);
    }
}

//Read a record and update GUI
async function readRecordById(){
    if(document.getElementById("list").selectedIndex===0){
        resetAllFields();
    }else{
        resetErrorMsg();
        let Id = document.getElementById("list").value;
        let response = await getRecordById(Id);
        if(response.status === 200){
            records = await response.json();
            let numberOfRecords = records.count;
            if(numberOfRecords===1){
                selectedId = records.data[0].id;
                document.getElementById("name").value = records.data[0].name;
                document.getElementById("no1").value = records.data[0].no1;
                document.getElementById("no2").value = records.data[0].no2;
                document.getElementById("buttonAction").setAttribute('value', 'Update');
                document.getElementById("buttonAction").setAttribute('onclick', 'updateRecord();');
                document.getElementById("buttonDelete").removeAttribute('hidden');
            }
        }else{
            alert("Selected Restaurant Not In The Database");
        }
    }
}

//Delete current record
async function deleteRecord(){
    const options = {
        method: "delete",
        headers: myHeaders
    };
    try{
        let response = await fetch(url + selectedId, options);
        if(response.status===204){
            renderAllRecords();
            alert('Delete Successfully');
        }else{
            alert('Delete Fail');
            console.log(await response.json());
        }
    } catch(error){
        console.log(error);
    }
}

//Update current record
async function updateRecord(){
    if(validate()===false){
        let name = document.getElementById("name").value;
        let no1 = document.getElementById("no1").value;
        let no2 = document.getElementById("no2").value;
        let updatedata = '{"name":"'+name+'","no1":"'+no1+'","no2":"'+no2+'"}';
        const options = {
            method: "put",
            headers: myHeaders,
            body: updatedata
        };
        try{
            let response = await fetch(url+selectedId,options);
            if(response.status===200){
                alert('Update Successfully');
            }else{
                alert('Update fail');
            }
        }catch(error){
            console.log(error);
        }
    }
}

//Insert current record
async function saveRecord(){
    if(validate()===false){
        let name = document.getElementById("name").value;
        let no1 = document.getElementById("no1").value;
        let no2 = document.getElementById("no2").value;
        let updatedata = '{"id":"'+lastID+'","name" : "'+name+'","no1":"'+no1+'","no2":"'+no2+'"}';
        const options = {
            method: "post",
            headers: myHeaders,
            body: updatedata
        };
        try{
            let response = await fetch(url,options);
            if(response.status===201){
                renderAllRecords();
                alert('Insert Successfully');
            }else{
                alert('Insert fail');
            }
        }catch(error){
            console.log(error);
        }
    }
}

//Clear all error message
function resetErrorMsg(){
    document.getElementById("namerror").innerHTML = "";
    document.getElementById("no1error").innerHTML = "";
    document.getElementById("no2error").innerHTML = "";
}

//Reset web page to default layout and settings
function resetAllFields(){
    selectedId = -1;
    resetInputFields();
    resetErrorMsg();
    document.getElementById("buttonAction").setAttribute('value','Save');
    document.getElementById("buttonAction").setAttribute('onclick','saveRecord();');
}

function validate(){
    resetErrorMsg();
    var error = false;
    
    return error;
}


