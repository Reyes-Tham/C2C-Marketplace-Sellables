<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <title>User-to-User Payment System with PayPal</title>
  <script src="https://www.paypal.com/sdk/js?client-id=AWh0gkbsMqEOY3BtEO1TllFYE4itO8kHuP_CJfqEezEvhHL20-87F9CbPCxEh6CuDyhNtVyidlwTBErZ"></script>
</head>
<body>
  <!-- PayPal button -->
  <div id="paypal-button-container"></div>

  <!-- JavaScript code -->
  <script>
    paypal.Buttons({
      createOrder: function(data, actions) {
        return actions.order.create({
          purchase_units: [{
            amount: {
              value: '0.01'
            },
          }]
        });
      },
      onApprove: function(data, actions) {
        return actions.order.capture().then(function(details) {
          // Show success message to the buyer
          alert('Transaction completed by ' + details.payer.name.given_name + '!');
        });
      }
    }).render('#paypal-button-container');
  </script>
</body>
</html>


